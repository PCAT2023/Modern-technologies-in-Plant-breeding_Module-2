###############################################################################################
###                  Scientific Training Center of Plant Biotechnologies                    ###
###       "Estimation of the parental lines genetic value for quantitative traits"          ###                           
###                               Regular course level                                      ###
###                    25 February 2022, Skoltech, Moscow, Russian Federation               ###
###                                                                                         ###
###                                       ----------                                        ###
###                                                                                         ###
###                                   - Line X Tester -                                     ### 
###                                          ----                                           ###
###     R Script edited by Pr Laurent Gentzbittel & Dr C�cile Ben, Skoltech                 ###
###############################################################################################

library(agricolae)
# example 1
data(heterosis)
heterosis
head(heterosis)
str(heterosis)
site1<-subset(heterosis,heterosis[,1]==1)
output1<-with(site1,lineXtester(Replication, Female, Male, v2))
#It makes the Line x Tester Genetic Analysis. 
#It also estimates the general and specific combinatory ability effects and the line and tester genetic contribution. 
#output: Standard Errors for combining ability effects. ANOVA with parents and crosses. ANOVA for line X tester analysis. ANOVA for line X tester analysis including parents. GCA Effects. Lines Effects. Testers Effects. Standard Errors for Combining Ability Effects. Genetic Components. Proportional contribution of lines, testers and their interactions. to total variance.
#References: Biometrical Methods in Quantitative Genetic Analysis, Singh, Chaudhary. 2010.