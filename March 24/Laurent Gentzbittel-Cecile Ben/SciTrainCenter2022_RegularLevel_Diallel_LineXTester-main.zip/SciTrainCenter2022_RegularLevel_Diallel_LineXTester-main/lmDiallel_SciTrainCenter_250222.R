###############################################################################################
###                  Scientific Training Center of Plant Biotechnologies                    ###
###       "Estimation of the parental lines genetic value for quantitative traits"          ###                           
###                               Regular course level                                      ###
###                    25 February 2022, Skoltech, Moscow, Russian Federation               ###
###                                                                                         ###
###                                       ----------                                        ###
###                                                                                         ###
###                 - Diallel analysis using lmDiallel R Package (Onofri et al, 2020)       ### 
###                                          ----                                           ###
###     R Script edited by Pr Laurent Gentzbittel & Dr C�cile Ben, Skoltech                 ###
###############################################################################################

######### PREPARATION OF THE WORKING INTERFACE IN R ###########################################
### I. Set working directory
#On RStudio: tab 'Session'-> Set Working Directory -> Choose Directory.
#Choose the directory containing the datafile and the associated R script.

### II. Installation R packages needed for the analysis on RStudio:
#Click on the 'Packages' tab in the bottom-right window of R Studio interface->'Install Packages'
#Comment #1: R package installation requires a connection to internet
#Comment #2: Once packages have been installed, no need to re-install them again when you close-open again RStudio.

### III. Initialisation of the working space
# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())
# use of the 'sum-to-zero' constraint for ANOVAs ## will see later in this script
options(contrasts=c('contr.sum','contr.poly'))
#can also use 'contr.treatment' for constraint 'set-to-zero' on effects for ANOVAs

#############################################################################################################
library(Hmisc)
library(gplots)
library(lattice)
library(car)    # Levene test
library(agricolae)   # Newman-Keuls & Tukey tests
library(MASS)
#############################################################################################################
# You can install lmDiallel from GitHub
# install.packages("devtools")
# devtools::install_github("onofriAndreaPG/lmDiallel")
#############################################################################################################
library(lmDiallel)

#############################################################################################################
###1st example: complete diallel with three parental lines (A, B and C)
###Adapted from https://www.r-bloggers.com/2020/11/lmdiallel-a-new-r-package-to-fit-diallel-models-the-haymans-model-type-1/
#############################################################################################################

library(tidyverse)
rm(list = ls())

#Import data (and modify dataset for our own use)
#FullDiallel <- read.table("https://www.casaonofri.it/_datasets/diallel1.csv", sep=',', header=T, stringsAsFactors = T)
#FullDiallel
#write.table(FullDiallel,'FullDiallel_3Parents_Yield.csv', sep=",", col.names=TRUE, row.names=FALSE)

df<-read.table('FullDiallel_3Parents_Yield.csv', sep=",", header=T, stringsAsFactors = T)
df$Block <- factor(df$Block)

str(df)

## What are the data ?
describe(df)

# To avoid typing the dataframe name
attach(df)

#################
# Graphics
#################

# xyplot in lattice, by genotype et repetition
x11()
xyplot( Yield ~  Block|Genotype)

#boxlpots
x11()
boxplot( Yield ~ Genotype, las=2)

tri<-sort(tapply(Yield, Genotype, mean))
x11()
boxplot( Yield ~ factor(Genotype, levels=names(tri)), las=2, xlab="Progeny")

### Other informative graph
library(ggplot2)
library(reshape2)
library(gridExtra)

# We 'organize' crosses
x11()
AvsB=df[c(1:8,13:20),]
AvsB.m=melt(AvsB)
pAvsB=ggplot(AvsB.m,aes(x=Genotype,y=value)) + geom_boxplot(fill="black",colour="red") + ggtitle("A vs B") + theme(plot.title = element_text(lineheight=.8, face="bold"),axis.text.x =element_text(size=7))

AvsC=df[c(1:4,9:12,25:28,33:36),]
AvsC.m=melt(AvsC)
pAvsC=ggplot(AvsC.m,aes(x=Genotype,y=value)) + geom_boxplot(fill="black",colour="red") + ggtitle("A vs C") + theme(plot.title = element_text(lineheight=.8, face="bold"),axis.text.x =element_text(size=7))

BvsC=df[c(17:24,29:36),]
BvsC.m=melt(BvsC)
pBvsC=ggplot(BvsC.m,aes(x=Genotype,y=value)) + geom_boxplot(fill="black",colour="red") + ggtitle("B vs C") + theme(plot.title = element_text(lineheight=.8, face="bold"),axis.text.x =element_text(size=7))


# to split the graphics window : 

grid.arrange(pAvsB,pAvsC,pBvsC,ncol=3)

#################
# First analysis : does Yield significantly differ among progenies ?
#################

ana1 <- aov(Yield ~ Genotype+Block)

summary(ana1)
# Conclusions ?

# Checking required conditions: Are residuals independent ?
#Independency is checked based on graphs
x11()
par(mfrow=c(2,2))
plot(ana1)

# Checking required conditions: Do residuals follow a Gaussian distribution ?
shapiro.test(residuals(ana1))

# Checking required conditions: Are variances of the residuals homogeneous?

## introducing Bartlett test for general comparisons of variances
# test of Brown-Forsythe, a variation of Levene's test
summary( aov(abs(residuals(ana1)) ~ Genotype+Block) )

#Bartlett's test (Snedecor and Cochran, 1983) is used to test if k samples have equal variances. Equal variances across samples is called homogeneity of variances. Some statistical tests, for example the analysis of variance, assume that variances are equal across groups or samples. The Bartlett test can be used to verify that assumption.
#Bartlett's test is sensitive to departures from normality. That is, if your samples come from non-normal distributions, then Bartlett's test may simply be testing for non-normality. The Levene test is an alternative to the Bartlett test that is less sensitive to departures from normality. 
bartlett.test(Yield ~ Genotype)              # Test on raw data of grain size (Caution! Not the good test to check ANOVA assumptions)
bartlett.test(abs(residuals(ana1)) ~ Genotype+Block)   # Test on residuals of ANOVA

# test of Brown-Forsythe, a variation of Levene's test
leveneTest(ana1, 'mean')
# Genuine Levene's test : using SS of residuals to the median (not to the mean). More robust
leveneTest(ana1, 'median')
## Your conclusions ?

## on transforme quand même ?
x11()
boxcox(aov(Yield~ Genotype+Block))
# lambda=0 : transfo log. But lambda=1 in the confidence interval so Useless to transform data.


#################
# Multiple means comparisons
##  this is the KEY result to decide about differences among progenies
#################
comparisons <- TukeyHSD(ana1) ## from base R
comparisons

print(SNK.test(ana1, "Genotype"))  ## from agricolae
print(HSD.test(ana1, "Genotype"))

## Post-hoc analysis : simple but useful figure
MultCompTest  <- SNK.test( ana1, trt = "Genotype", console = TRUE ) 
x11()
plot(MultCompTest, las=2)  

# The Yield is significantly different according to the progeny.
# All progenies have been compared in the same environment so the effect of environmental factors is the same for all genotypes.
# Warning! The environment-genotype interaction is not taken into account
# In this hypothesis, if we find that the means of the 2 progenies for the yield are statistically different then the difference is due to hereditary factors.
# There is therefore genetic variability for the genes involved in controlling our trait of interest. PRE-REQUIREMENTS FOR ANY SELECTION
# For some of the studied trait, the yield is subject to a superdominance effect.

######################
#In order to describe the above dataset, we might think of a two-way ANOVA model, 
#where the 'father' and 'mother' lines (the 'Par1' and 'Par2' variables, respectively) are used as the explanatory factors.

#This is a very tempting solution, but we should resist: a two way ANOVA model regards the 'father' and 'mother' effects as two completely different series of treatments, 
#neglecting the fact that they are, indeed, the same genotypes in different combinations. 
#That is exactly why we need specific diallel models to describe the results of diallel experiments!

######
#The Griffing's models (1956)-full diallel experiments (including selfs and reciprocals; mating scheme 1)
######
#With full diallel experiments (including selfs and reciprocals; mating scheme 1), 
#the model is very similar to Hayman's model type 1, 
#except that reciprocal effects are not parted into RGCA and RSCA (Reciprocal General Combining Ability and Reciprocal Specific Combining Ability). 

#The equation is: yijk=??+gi+gj+tsij+rij+??ijk(1)

#where ?? is the expected value (the overall mean, in the balanced case)
#??ijk is the residual random error term for the observation in the kth block and with the parentals i and j. 

#All the other terms correspond to genetic effects, namely:
  
#the gi and gj terms are the General Combining Abilities (GCAs) of the ith and jth parents.
#The tsij term is the total Specific Combining Ability (SCA) for the combination ij.
#The rij term is the reciprocal effect for a specific ij combination.

contrasts(df$Block) <- "contr.sum"
dMod_G1 <- lm(Yield ~ Block + GCA(Par1, Par2) + tSCA(Par1, Par2) +
             REC(Par1, Par2), data = df)
anova(dMod_G1)
summary(dMod_G1)


dMod2_G1 <- lm.diallel(Yield ~ Par1 + Par2, Block = Block,
                    data = df, fct = "GRIFFING1")
anova(dMod2_G1)
summary(dMod2_G1)

#In order to obtain the full list of genetical parameters
library(multcomp)
gh_G1 <- glht(linfct = diallel.eff(dMod2_G1))
summary(gh_G1, test = adjusted(type = "none")) 

#Constraint on effects = sum-to-zero
#ex: gC=-(gA+gB)
-(-2.167e+00+-1.667e-01)
######
#The "Hayman" model (type 1): first diallel model proposed by Hayman (1954) and devised for complete diallel experiments, where reciprocals are available. 
######

#Neglecting the design effects (blocks and/or environments), the Hayman's model is defined as:
#yijk=??+gi+gj+tsij+rgai+rgbj+rsij+??ijk(Eq.1)

#where ?? is expected value (the overall mean, in the balanced case)
#??ijk is the residual random error terms for the observation in the kth block and with the parentals i and j. 
#All the other terms correspond to genetic effects, namely:

#1. GCA: General Combining Abilities
#the gi and gj terms are the general combining abilities (GCAs) of the ith and jth parents. 
#Each term relates to the average performances of a parental line in all its hybrid combination, 
#under the sum-to-zero constraint (i.e. the sum of g values for all parentals must be zero). 
#For example, with our balanced experiment, the overall mean is ??=15.33, 
#while the mean for the A parent when used as the 'father' is ??A.=13 and the mean for the same parent A when used as the 'mother' is ??.A=13.33. 
#Consequently:
#gA=(13+13.33)/2-15.33=???2.167
#gB=???0.167
#gC=-(gA+gB)

#2. reciprocal general combining abilities (RGCAs)
#The rgai and rgbj terms are the reciprocal general combining abilities (RGCAs) for the ith and jth parents. 
#Each term relates to the discrepancy between the effect of a parent when it is used as father/mother 
#and its average effect in all its combinations. 
#For example, considering the parent A, the term rgaA is:
#rgaA=??A.-(??A.+??.A)/2=13-13.167=???0.167
#Obviously, it must be rgaA=-rgbB and it must also be that the sum of all rga terms is zero (sum-to-zero constraint).

#3. specific combining ability (tSCA) 
#The tsij term is the total specific combining ability (tSCA) for the combination between the ith and jth parents. 
#It relates to the discrepancy from additivity for a specific combination of two parentals. 
#For example, considering the 'A � B' cross, the expected yield under additivity would be:
#??A:B=??+gA+gB+rgaA+rgbB=
#=15.33-2.167-0.167-0.167-0.5=12.333
#while the observed yield is 13, with a with a difference of ???0.667. 
#On the other hand, considering the 'B � A' reciprocal cross, the expected yield under additivity would be:
#??A:B=??+gA+gB+rgaB+rgbA=
#=15.33-2.167-0.167+0.167+0.5=13.667
#while the observed yield is 11, with a difference of 2.667. 
#The tSCA for the cross between A and B (regardless of the reciprocal) is the average difference, 
#that is tsAB=(???0.667+2.667)/2=1.

#4. reciprocal specific combining ability (RSCA)
#The rsij term is the reciprocal specific combining ability (RSCA) for a specific ij combination, 
#that is the discrepancy between the performances of the two reciprocals (e.g, A � B vs. B � A). 
#For example, the rsAB term is equal to ???0.667-1=???1.667, that is the opposite of rsBA.

#Hands-calculations based on means may be useful to understand the meaning of genetical effects, 
#although they are biased with unbalanced designs 
#bove all, they are totally uninteresting from a practical point of view: we'd rather fit the model by using a statistical software.

######
##"Hayman" model (type 1) - Model fitting with R
######
#Let's assume that all effects are fixed, apart from the residual standard error. 
#This is a reasonable assumption, as we have a very low number of parentals, which would make the estimation of variance components totally unreliable. 

dMod_H1 <- lm(Yield ~ Block + GCA(Par1, Par2) + tSCA(Par1, Par2) +
             RGCA(Par1, Par2) + RSCA(Par1, Par2), data = df)
summary(dMod_H1)
anova(dMod_H1)

#Using the wrapper function named lm.diallel()
#lm.diallel(formula, Block, Env, data, fct)
#where 'formula' specifies the response variable and the two variables for parentals (e.g., Yield ~ Par1 + Par2) 
#'Block' and 'Env' are used to specify optional variables, coding for blocks and environments, respectively. 
#'data' is a 'dataframe' where to look for the explanatory variables, 
#'fct' is a string variable coding for the selected model ("HAYMAN1", for this example; see below).

dMod2_H1 <- lm.diallel(Yield ~ Par1 + Par2, Block = Block,
                    data = df, fct = "HAYMAN1")
summary(dMod2_H1)
anova(dMod2_H1)

#The genetical parameters can be obtained by using the glht() function 
#and passing the information from the first step within the call to the diallel.eff() function.

library(multcomp)
gh_H1 <- glht(linfct = diallel.eff(dMod2_H1))
summary(gh_H1, test = adjusted(type = "none")) 

#############################
###Model fitting in two steps
#############################

#In some cases, the analysis is performed in two steps and a diallel model is fitted to the means of selfs and crosses, 
#which are calculated in the first step. 
#group_by() function in the 'dplyr' package to obtain the means and standard errors for all crosses and selfs.
dfM <- df %>% 
  group_by(Par1, Par2) %>% 
  summarise(YieldM = mean(Yield), SEs = sd(Yield/sqrt(4)))
dfM

#Under the assumption of variance homogeneity and equal number of replicates, we can fit the Hayman's model by using the lm.diallel() function without the 'Block' argument.
dMod3_H1 <- lm.diallel(YieldM ~ Par1 + Par2, 
                    data = dfM, fct = "HAYMAN1")
#In this case, we have no reliable estimate of residual error, but the summary() and anova() methods have been enhanced to give us the possibility of passing some information from the first step, 
#i.e. an appropriate estimate of the residual mean square and degrees of freedom; 
#the residual mean square from the first step needs to be appropriately weighted for the number of replicates (i.e., for this example, MSE = 3.007/4 with 24 degrees of freedom).
summary(dMod3_H1, MSE = 3.007/4, dfr = 24)

#The genetical parameters can be obtained by using the glht() function 
#and passing the information from the first step within the call to the diallel.eff() function.

gh2_H1 <- glht(linfct = diallel.eff(dMod3_H1, MSE = 3.007/4, dfr = 24))
summary(gh2_H1, test = adjusted(type = "none")) 
anova(dMod3_H1, MSE = 3.007/4, dfr = 24)

##########################################################
###Estimation of variance components (random genetic effects)
##########################################################

#In some cases, genetic effects are regarded as random and the aim is to estimate variance components. 
#For this, we can use the mmer() function in the 'sommer' package (Covarrubias-Pazaran, 2019), 
#although we need to code two dummy variables:
  
#'dr': assuming a value of zero for selfs, a value of -1 for crosses and 1 for the respective reciprocals;
#'combination': which gives the reciprocals the same label (i.e. BA is given the same label as AB), so that any difference is erased.
#By using the overlay() function in the 'sommer' package and the above dummy variables, we can code the following effects:
  #GCA effect: ~overlay(Par1, Par2)
  #RGCA effect: ~overlay(Par1, Par2):dr (please, note that the interaction with 'dr' excludes the selfs, which are coded as 0s, and distinguish the reciprocals, as they are coded with opposite signs)
  #SCA effect : ~combination (reciprocals are not considered)
  #RSCA effect: ~combination:dr (same note as above for RGCA)

#It would make no sense to estimate the variance components for genetic effects with a diallel experiment based on 3 parentals. 
#Therefore, we give an example based on the 'hayman54' dataset, as available in the 'lmDiallel' package and relating to a complete diallel experiment with eight parentals (Hayman, 1954).
#The example in Hayman (1954) relates to a complete diallel experiment with eight parental lines, producing 64 combinations (8 selfs + 28 crosses with 2 reciprocals each).

rm(list=ls())
library(sommer)
library(lmDiallel)
data(hayman54)
# Dummy variables
hayman54$dr <- ifelse(as.character(hayman54$Par1) < as.character(hayman54$Par2), -1,
                      ifelse(as.character(hayman54$Par1) == as.character(hayman54$Par2), 0, 1))
hayman54$combination <- factor( ifelse(as.character(hayman54$Par1) <=
                                         as.character(hayman54$Par2),
                                       paste(hayman54$Par1, hayman54$Par2, sep =""),
                                       paste(hayman54$Par2, hayman54$Par1, sep ="")) )
mod1h <- mmer(Ftime ~ Block, data = hayman54, 
              random = ~ overlay(Par1, Par2)
              + overlay(Par1, Par2):dr
              + combination
              + combination:dr, verbose = F)
summary(mod1h)$varcomp

############################
###The Hayman's model type 2
############################
#The Hayman's model type 2 is derived from type 1 , 
#by partitioning the tSCA effect in three additive components. The equation is:
  
  #yijk=??+??k+gi+gj+m+di+dj+sij+rgai+rgbj+rsij+??ijk for i???j
  #yijk=??+??k+2gi-(n-1)m-(n-2)di+??ijk  for i=j
  
#where ?? is the expected value (the overall mean, in the case of fully orthogonal designs), 
#n is the number of parentals 
#??ijk is the residual random error term. 

#All the other terms correspond to genetic effects, namely:
  #the gi and gj terms are the general combining abilities (GCAs) of the ith and jth parents.
  #The rgai and rgbj terms are the reciprocal general combining abilities (RGCAs) for the ith and jth parents.
  #The m term relates to the difference between the average value of all observations and the average values of crosses (Mean Dominance Deviation; MDD).
  #The di and dj terms relate to the differences between the yield of each selfed parent (Yij, with i=j) and the average yield of all selfed parents (dominance deviation for the ith parent; DD).
  #The term sij is the SCA effect for the combination ij.
  #The rsij term is the reciprocal specific combining ability (RSCA) for a specific ij combination, that is the discrepancy between the performances of the two reciprocals (e.g, A � B vs. B � A).

#Similarly to type 1, the Hayman's model type 2 considers the genetical effects as differences with respect to the intercept ??, that is the mean of all observations (when the design is orthogonal). 
#However, with respect to type 1, this latter model permits the estimation of a higher number of genetic effects (GCAs, RGCAs, MDD, DDs, SCAs and RSCAs) and provides an approach to quantify heterotic effects. 
#We should consider that, due to unbalance (the number of crosses is never equal to the number of selfs), it is necessary to introduce some coefficients (i.e. n-1 and n-2 in Equation 1), which do not have an obvious meaning. 
#Other diallel models were proposed, which account for heterotic effects in a different manner (Gardner and Eberhart, 1966).

#############  
#The Hayman's model type 2 - Model fitting with R
#############
#Let's assume that all effects are fixed, apart from the residual error effect. 
contrasts(hayman54$Block) <- "contr.sum"

dMod_H2 <- lm(Ftime ~ Block + GCA(Par1, Par2) + MDD(Par1, Par2) +
             DD(Par1, Par2) + SCA(Par1, Par2) +
             RGCA(Par1, Par2) + RSCA(Par1, Par2), data = hayman54)
summary(dMod_H2)$coef[1:6,]
anova(dMod_H2)

dMod2_H2 <- lm.diallel(Ftime ~ Par1 + Par2, Block = Block,
                    data = hayman54, fct = "HAYMAN2")
# summary(dMod2)
anova(dMod2_H2)

#to retrieve the complete list of genetical parameters. 
library(multcomp)
gh_H2 <- glht(linfct = diallel.eff(dMod2_H2))

#############
#Estimation of variance components (random genetic effects)
#############
# Random genetic effects
mod1m_H2 <- mmer.diallel(Ftime ~ Par1 + Par2, Block = Block, 
                      data = hayman54,
                      fct = "HAYMAN2")
mod1m_H2

############################
###Example 2: The Griffing's models (1956)- no reciprocals (Model 2)
############################

#As an example of a diallel experiments with no reciprocals, we consider the data reported in Lonnquist and Gardner (1961) 
#relating to the yield of 21 maize genotypes, obtained from six male and six female parentals.

#When the reciprocal crosses are not available (mating scheme 2), the term rij needs to be dropped, so that the model reduces to:
#yijk=??+gi+gj+tsij+??ijk

rm(list=ls())
data(lonnquist61)
head(lonnquist61)
str(lonnquist61)

dMod_G2 <- lm(Yield ~ GCA(Par1, Par2) + tSCA(Par1, Par2), 
           data = lonnquist61)
#In this case the dataset has no replicates and, for the inferences, we need to provide an estimate of the residual mean square and degrees of freedom
anova.diallel(dMod_G2, MSE = 7.1, dfr = 60)
#summary.diallel(dMod_G2, MSE = 7.1, dfr = 60)


dMod2_G2 <- lm.diallel(Yield ~ Par1 + Par2,
                    data = lonnquist61, fct = "GRIFFING2")
anova(dMod2_G2, MSE = 7.1, dfr = 60)
#summary(dMod2_G2, MSE = 7.1, dfr = 60)

#we can retrieve the full list of genetical parameters
gh_G2 <- glht(linfct = diallel.eff(dMod2_G2, MSE = 7.1, dfr = 60))
summary(gh_G2, test = adjusted(type = "none"))

##########
###Estimation of variance components (random genetic effects)
##########

#If we intend to regard the genetic effects as random and to estimate variance components, 
#we can use the mmer() function in the 'sommer' package (Covarrubias-Pazaran, 2016), 
#although we need to code a bunch of dummy variables. 
#In order to make things simpler for routine experiments, we have coded the mmer.diallel() wrapper using the same syntax as the lm.diallel() function. 
#The exemplary code relates to Equation 2, although the other equations can be fitted in a similar manner.

# Random genetic effects
mod1m_G2 <- mmer.diallel(Yield ~ Par1 + Par2,
                      data = lonnquist61,
                      fct = "GRIFFING2")
mod1m_G2

############################
###Example 3: The Griffing's models (1956)- no selfs (Model 3)
############################

#When the experimental design includes the reciprocal crosses but not the selfs, we can fit Equation 3. 
#As an example, we take the same dataset as before ('hayman54'), but we remove the selfs by using 'dplyr'. 

#When the reciprocals are available, but selfs are missing (mating scheme 3), 
#the model is similar to equation 1, but the term tsij is replaced by sij 
#(we use a different symbol, because the design matrix is slightly different and needs a different coding):
#yijk=??+gi+gj+sij+rij+??ijk

library(dplyr)
data(hayman54)
hayman54b <- hayman54  %>% 
  filter(Par1 != Par2)

dMod_G3 <- lm(Ftime ~ Block + GCA(Par1, Par2) + 
             SCA.G3(Par1, Par2) + REC.G3(Par1, Par2), 
           data = hayman54b)
anova(dMod_G3)

dMod2_G3 <- lm.diallel(Ftime ~ Par1 + Par2, Block = Block,
                    data = hayman54b, fct = "GRIFFING3")
anova(dMod2_G3)

gh_G3 <- glht(linfct = diallel.eff(dMod2_G3))
summary(gh_G3, test = adjusted(type = "none"))

############################
###Example 4: The Griffing's models (1956)- no reciprocals, no selfs (Model 4)
############################
#mating scheme where neither the reciprocal crosses nor the selfs are included (mating scheme 4). 
#The dataset is taken from the original Griffing's paper (Griffing, 1956)
#when neither selfs nor reciprocals are available (mating scheme 4), the equation reduces to:
#yijk=??+gi+gj+sij+??ijk
#we input the appropriate residual error term to obtain the correct inferences, as the original dataset does not contain the replicated data.

data("griffing56")
head(griffing56)
str(griffing56)

dMod_G4 <- lm(Yield ~ GCA(Par1, Par2) + SCA.G3(Par1, Par2), 
           data = griffing56)
anova.diallel(dMod_G4, MSE = 21.05, dfr = 2558)

dMod2_G4 <- lm.diallel(Yield ~ Par1 + Par2,
                    data = griffing56, fct = "GRIFFING4")
anova(dMod2_G4, MSE = 21.05, dfr = 2558)

gh_G4 <- glht(linfct = diallel.eff(dMod2_G4, MSE = 21.05, dfr = 2558))
summary(gh_G4, test = adjusted(type = "none"))