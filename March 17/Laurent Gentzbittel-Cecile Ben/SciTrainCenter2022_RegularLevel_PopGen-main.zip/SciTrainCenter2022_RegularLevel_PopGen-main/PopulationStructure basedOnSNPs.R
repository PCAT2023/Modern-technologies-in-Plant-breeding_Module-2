#' ---
#' title:  |
    #'   | Determining population structure
    #' author:
    #'   - Prof L. Gentzbittel Skoltech, Project Center for Agro Technologies ^[l.gentzbittel@skoltech.ru]
    #'   - Prof C. Ben, Skoltech, Project Center for Agro Technologies ^[c.ben@skoltech.ru]
    #' date: "Feb 2022 - Skoltech"
    #' output: 
    #'   pdf_document:
    #'     keep_tex: true
    #' use_bookdown: TRUE
    #' latex_engine: xelatex
    #' header-includes:
#'   - \usepackage{bbold}
#'   - \def\+#1{\mathbf{#1}}
#' geometry: left = 2cm, right = 1.5cm, top = 1.5cm, bottom = 1.5cm
#' ---
#' 
#+ echo = FALSE, message = FALSE, warning = FALSE
# just forgot these lines. They are used to generate the printed version
knitr::opts_chunk$set(fig.width = 7, fig.height=6, warning=FALSE, message=FALSE,
                      tidy.opts=list(width.cutoff=80), tidy=TRUE)
# Now we resume to nominal situation
#' 
#' # CASE STUDY PRESENTATION 
#' 16,000 SNPs on the Medicago truncatula genome, along with some geographical coordinates.


### III. Initialisation of the working space
# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())

# this is a trick to detect which folder contains the R script and the data
main_dir <- dirname(rstudioapi::getSourceEditorContext()$path) 
setwd(main_dir)

#'
#' # LOADING REQUIRED METHODS FOR ANALYSIS 
#'
library(adegenet)
library(ape) 

library(ggplot2)


###################
# Data import in R
###################

## -------------------  Using the results of Admixture ------------------- ##
CVAdmixture <- read.table("CV_sampled.csv", sep = ";", header = TRUE)


## -------------------  Using multivariate methods --- ------------------- ##




# data were formated using plink1.9 in plink's raw format
#
## caution :  this (not a very) large dataset that will require lots of computation time to do the course. Use it as your own risks !
## SNPs <- read.PLINK("../data/KrAllSubset240K.raw", map.file = "../data/KrAllSubset240K.map", n.cores = 6, chunkSize = 50)
#
## This is a lighter dataset, for fast computations
 SNPs <- read.PLINK("KrAllSubset16K.raw", map.file = "KrAllSubset16K.map", n.cores = 1)
# chunkSize is the number of genomes to be read at a time.

SNPs


# additional information on accessions 
# shall be in the SAME order as in SNPs
Infos <- read.table("AccessionsGeography.csv", sep=";", header=TRUE)

# geo-cordinates (lat/long) in the 'other' slot of SNPs
other(SNPs)$xy <- Infos[,c("Long", "Lat")]

SNPs
SNPs@other$xy
    

# faster to reload than generating the object again :
save(SNPs, file = "SNPs.RData")
## # if needed reload SNPs object by :
## load("SNPs.RData")



## One can easily derive the distributiong of allele frequencies using:
## glMean: computes the mean of second alleles, i.e. second allele frequencies for each SNP.

myFreq <- glMean(SNPs)

x11()
hist(myFreq, proba = TRUE, col = "gold", xlab = "Allele frequencies",
main="Distribution of (second) allele frequencies")
temp <- density(myFreq)
lines(temp$x, temp$y*1.8, lwd = 3)


## However, the distribution of allele frequencies may be more interpretable by restoring its native symmetry:

myFreq <- c(myFreq, 1-myFreq)

x11()
hist(myFreq, proba = TRUE, col = "darkseagreen3", xlab = "Allele frequencies",
main = "Distribution of allele frequencies", nclass=20)
temp <- density(myFreq, bw=.05)
lines(temp$x, temp$y*2, lwd=3)



## ------------------ hierarchical clustering ------------------ ##

D <- dist(as.matrix(SNPs))

## save distance matrix 
save(D, file = "DistanceMatrix.RData")
## reload, without recomputing,  using
## load("DistanceMatrix.RData")


h1 <- hclust(D, method="complete")
h1

x11()
plot(h1, labels = FALSE)
# looks 5 or 6 groups

grp1 <- cutree(h1, k = 5)
head(grp1, 50)


grp2 <- cutree(h1, k = 6)
head(grp2, 100)

## tabulate groups :
x11()
table.value(table(grp2, grp1), col.lab=paste("grp", 1:15))
# K = 5?



## ------------------ principal component Analysis ------------------ ##


### PCA , a first, useful dimension reduction
ptm <- proc.time()

PCA1 <- glPca(SNPs, center = TRUE, scale = FALSE, nf = 200, loadings = TRUE, 
              alleleAsUnit = FALSE, useC = FALSE, parallel = TRUE,
              n.cores = 1, returnDotProd = FALSE, matDotProd = NULL)

(Temps.glPca <- proc.time() - ptm)
## about 5 minutes

## save PCA analysis
save(PCA1, file = "PCA1_glPca.RData")
## reload using
## load("PCA1_glPca.RData")

## save ALL workspace before continuing, in case of problems
save.image(file = "PopStructStep1.RData")


x11()
scatter(PCA1, posi="bottomleft")
title("PCA of Mtr accessions\n axes 1-2, 16.000 SNPs")
## the PCA show


## comparisons with distance-based trees :


tre <- nj(D)
tre
# useful ?
x11()
plot(tre, typ="fan", cex = 0.7)
title("NJ tree of Mtr accessions")


# compare PCA and NJ tree with colors.
# Use mix of RGB of three fist components to create colors. see ?colorplot
x11()
myCol <- colorplot(PCA1$scores, PCA1$scores, transp = TRUE, cex = 4)
abline(h = 0,v = 0, col = "grey")
##add.scatter.eig(PCA1$eig[1:40],2,1,2, posi="bottomright", inset=.05, ratio=.3)
x11()
plot(tre, type = "fan", show.tip = FALSE)
tiplabels(pch = 20, col = myCol, cex = 3.5)
title("NJ tree of Mtr accessions")


## Kmeans :
grp1 <- find.clusters(SNPs, max.n.clust = 40, n.pca = 200,
                      choose.n.clust = FALSE, criterion = "min",
                      n.start = 120, glPca = PCA1)
grp1

# to draw using ggplot
bic <- data.frame(K = seq(1:40), bic = grp1$Kstat)

x11()
(BIC1 <- ggplot(bic, aes(x = K, y = bic)) +
        geom_line( color = "firebrick", size = 1.2))


## DAPC
## We want to assess the relationships between these groups using DAPC.
## Perform the DAPC and store the results in a new object called dapc:

dapc1 <- dapc(SNPs, pop = grp1$grp, scale = FALSE, n.pca = 200, n.da=8,
              glPca = PCA1)


save( dapc1, file= "dapc1_ana.RData")
## load("dapc1_ana.RData")
save.image(file = "outPopStructStep2.RData")


#png("dapc1_optim.png")

x11()
scatter(dapc1, scree.da = FALSE, bg="white",
        pch=20, cell=0, cstar=0, col=funky(5), solid=.4,
        cex=3,clab=0, leg=TRUE, txt.leg=paste("Cluster",1:5))


x11()
scatter(dapc1, xax=2, yax = 3,
        scree.da = FALSE, bg="white",
        pch=20, cell=0, cstar=0, col=funky(5), solid=.4,
        cex=3,clab=0, leg=TRUE, txt.leg=paste("Cluster",1:5))


# How the dapc is discriminating the groups ?
x11()
par(mfrow=c(3,1))
scatter(dapc1, 1, 1,
        col= funky(5), bg = "white",
        scree.da = FALSE, legend=TRUE, solid=.4)
scatter(dapc1, 2, 2,
        col = funky(5), bg = "white",
        scree.da = FALSE, legend = TRUE, solid=.4)
scatter(dapc1, 3, 3,
        col = funky(5), bg = "white",
        scree.da = FALSE, legend = TRUE, solid=.4)



##  Membership probabilities are based on the retained discriminant functions.
## They are stored in dapc objects in the slot posterior. this may be used to GWAS analyses

class(dapc1$posterior)
dim(dapc1$posterior)
round(head(dapc1$posterior),3)


## drawing a Structure-like plot (need some tricks)
tbl <- dapc1$posterior
tbl <- as.data.frame(tbl)
# major group for each accession
maxi <- function(x){which(x==max(x))}
tbl$Major <- apply( tbl, 1, maxi)
# ordering accessions by group
ORDER <- order(tbl$Major)


## M. truncatula putative structure based on DAPC analysis"

x11()
barplot( t(tbl[ORDER, -6]) , col = funky(5), border = NA,
        xlab = "accessions ", ylab = "Posterior probability", 
        names.arg = rownames(tbl),
        cex.names = 0.30, las = 2, cex.axis = 1,
        main='Mtr accessions, DAPC analysis'
        )

