#' ---
#' title:  |
  #'   | Key quantities in population genetics
  #' author:
  #'   - Prof L. Gentzbittel Skoltech, Project Center for Agro Technologies ^[l.gentzbittel@skoltech.ru]
  #'   - Prof C. Ben, Skoltech, Project Center for Agro Technologies ^[c.ben@skoltech.ru]
  #' date: "March 2023 - Skoltech"
  #' output: 
  #'   pdf_document:
  #'     keep_tex: true
  #' use_bookdown: TRUE
  #' latex_engine: xelatex
  #' header-includes:
#'   - \usepackage{bbold}
#'   - \def\+#1{\mathbf{#1}}
#' geometry: left = 2cm, right = 1.5cm, top = 1.5cm, bottom = 1.5cm
#' ---
#' 
#+ echo = FALSE, message = FALSE, warning = FALSE
# just forgot these lines. They are used to generate the printed version
knitr::opts_chunk$set(fig.width = 7, fig.height=6, warning=FALSE, message=FALSE,
                      tidy.opts=list(width.cutoff=80), tidy=TRUE)
# Now we resume to nominal situation
#' 
#' # CASE STUDY PRESENTATION 
#' 
#' 329 individuals of Solanum rostratum were genotyped at 10 microsatellite loci to determine the levels of genetic diversity and to investigate population structure of native and introduced populations of this plant . We studied five populations in each of three regions across two continents: Mexico, the U.S.A. and China.
#' 

### III. Initialisation of the working space
# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())

# this is a trick to detect which folder contains the R script and the data
main_dir <- dirname(rstudioapi::getSourceEditorContext()$path) 
setwd(main_dir)

#'
#' # LOADING REQUIRED METHODS FOR ANALYSIS 
#'
library(pegas)


SSRs <- read.loci("Solanum_SSR-Genotypedata-PONE.csv", loci.sep = ",", 
                  col.loci = 4:13, row.names = 1)


print(SSRs, details = TRUE)
str(SSRs)

View(SSRs) ## in case of
getAlleles(SSRs)


library(adegenet)
## using the adegenet library: change the format of data
SSR2 <- loci2genind(SSRs, ploidy = 2, na.alleles = "NA")
SSR2@pop <- SSRs$SITE  # a choice
# indicating countries and sites within countries
strata(SSR2) <- SSRs[, c(1:2)]
SSR2
# describe data
div <- summary(SSR2)
print(div)
names(div)

## Hardy-Weinberg test.
hw.test(SSR2)
# Are the results expected given Solanum biology ?


library(hierfstat)
## using the hierfstat library: change the format of data
SSR2.hfstatPerSite <- genind2hierfstat(SSR2)
head(SSR2.hfstatPerSite) # as expected , population is defined by SITE
( basicstatPerSite <- basic.stats(SSR2.hfstatPerSite, diploid = TRUE, digits = 2)) 

SSR2@pop <- SSRs$Country  # let's define population by countries
SSR2.hfstatPerCountry <- genind2hierfstat(SSR2)
head(SSR2.hfstatPerCountry)
( basicstatPerCountry <- basic.stats(SSR2.hfstatPerCountry, diploid = TRUE, digits = 2)) 
names(basicstatPerCountry)


# some of the above quantities can be also computed using the mmod library
library(mmod)   # can use genind objects from adegenet

setPop(SSR2) <- ~ Country  # Use ~SITE to analyse per site
diff_Country <- diff_stats(SSR2)
diff_Country

setPop(SSR2) <- ~ SITE  
diff_Site <- diff_stats(SSR2)
diff_Site

