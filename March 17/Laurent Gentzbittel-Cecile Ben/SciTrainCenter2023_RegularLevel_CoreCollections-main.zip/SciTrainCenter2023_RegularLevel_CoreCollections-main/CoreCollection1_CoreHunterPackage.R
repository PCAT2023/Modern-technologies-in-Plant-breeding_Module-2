#' ---
#' title:  |
#'   | Computing core collections
#'   | Scientific Training Center - Regular Level
#' author:
#'   - Prof L. Gentzbittel Skoltech, Project Center for Agro Technologies ^[l.gentzbittel@skoltech.ru]
#'   - Prof C. Ben, Skoltech, Project Center for Agro Technologies ^[c.ben@skoltech.ru]
#' date: "March 2023 - Skoltech"
#' output: 
#'   pdf_document:
#'     keep_tex: true
#' use_bookdown: TRUE
#' latex_engine: xelatex
#' header-includes:
#'   - \usepackage{bbold}
#'   - \def\+#1{\mathbf{#1}}
#' geometry: left = 2cm, right = 1.5cm, top = 1.5cm, bottom = 1.5cm
#' ---
#' 
#+ echo = FALSE, message = FALSE, warning = FALSE
# just forgot these lines. They are used to generate the printed version
knitr::opts_chunk$set(fig.width = 7, fig.height=6, warning=FALSE, message=FALSE,
                      tidy.opts=list(width.cutoff=80), tidy=TRUE)
# Now we resume to nominal situation


# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())
gc()

# This is a trick to detect which folder contains the R script and the data
main_dir <- here::here()
setwd(main_dir)


library(corehunter)
library(tidyverse)

# if (!require(devtools)) install.packages("devtools")
# devtools::install_github("yanlinlin82/ggvenn")
library(ggvenn)

# Example to create from data frame or matrix, to understand their content:
# default format
( geno.data <- data.frame(
  NAME = c("Alice", "Bob", "Carol", "Dave", "Eve"),
  M1.1 = c(1,2,1,2,1),
  M1.2 = c(3,2,2,3,1),
  M2.1 = c("B","C","D","B",NA),
  M2.2 = c("B","A","D","B",NA),
  M3.1 = c("a1","a1","a2","a2","a1"),
  M3.2 = c("a1","a2","a2","a1","a1"),
  M4.1 = c(NA,"+","+","+","-"),
  M4.2 = c(NA,"-","+","-","-"),
  row.names = paste("g", 1:5, sep = "-")
) )
( geno <- genotypes(geno.data, format = "default") )


# biparental (e.g. SNP)
( geno.data <- matrix(
  sample(c(0,1,2), replace = TRUE, size = 1000),
  nrow = 10, ncol = 100
) )

rownames(geno.data) <- paste("g", 1:10, sep = "-")
colnames(geno.data) <- paste("m", 1:100, sep = "-")
geno.data
( geno <- genotypes(geno.data, format = "biparental") )


# frequencies
geno.data <- matrix(
  c(0.0, 0.3, 0.7, 0.5, 0.5, 0.0, 1.0,
    0.4, 0.0, 0.6, 0.1, 0.9, 0.0, 1.0,
    0.3, 0.3, 0.4, 1.0, 0.0, 0.6, 0.4),
  byrow = TRUE, nrow = 3, ncol = 7
)
rownames(geno.data) <- paste("g", 1:3, sep = "-")
colnames(geno.data) <- c("M1", "M1", "M1", "M2", "M2", "M3", "M3")
alleles <- c("M1-a", "M1-b", "M1-c", "M2-a", "M2-b", "M3-a", "M3-b")
geno.data
( geno <- genotypes(geno.data, alleles, format = "frequency") )


## -----------   Go with real data   -----------  ##
# Description:
# Data was genotyped using 190 SNP markers for 218 accessions and 4 quantitative traits were recorded. It includes:
# a precomputed distance matrix read from "extdata/distances.csv", 
# genotypes read from "extdata/genotypes-biparental
# phenotypes read from "extdata/phenotypes.csv". 
# The distance matrix is computed from the genotypes (Modified Rogers' distance).

# Data was taken from the CIMMYT Research Data Repository (Study Global ID hdl:11529/10199; real data set 5, cycle 0).
# Ceron-Rojas, J.J., Toledo, F.H., Crossa, J., 2019. The Relative Efficiency of Two Multistage Linear Phenotypic Selection Indices to Predict the Net Genetic Merit. Crop Science 59, 1037-1051. https://doi.org/10.2135/cropsci2018.11.0678


data <- exampleData()
data  ## genotypes are in 'biparental coding'. 

## some visualisations and computations to help to evaluate the core collections
## using PCA, kmeans and DAPC
library(adegenet)

## recoding allele content into genotype coding
blirf <- data$geno$data
blirf[blirf==2] <- 'BB'
blirf[blirf==1] <- 'AB'
blirf[blirf==0] <- 'AA'

## create an 'genind' object to use adegenet functions
dataGenet <- df2genind(blirf, ind.names= data$names, ploidy = 2, sep="", ncode = 1)
dataGenet
summary(dataGenet)

dataGenet[1:5, loc="M1"]@tab
dataGenet[1:5, loc="M2"]@tab
## compare to:
data$geno$data[1:5, 1:2]

## PCA uses allelic frequencies. Let's comupte them as follows
AllFreq <- tab(dataGenet, freq = TRUE, NA.method = "mean")
AllFreq[1:5, 1:4]
data$geno$data[1:5, 1:2]

class(AllFreq)
dim(AllFreq)

## perfom PCA on genind object: the  dudi.pca function
pca.Maize <- dudi.pca(AllFreq, center = TRUE, scale = FALSE, 
                      scannf = FALSE, nf = 100)
x11()
barplot(pca.Maize$eig[1:50], main = "PCA eigenvalues", col = heat.colors(50))

# plot of entries, coloured in RGB using the coordinates on PCA1, PC2 and PCA3 ( see Regular Level, PopGen)
x11()
par(mfrow=c(1,2))  ## two figure in one
colorplot(pca.Maize$li, pca.Maize$li, transp=TRUE, cex=3, xlab="PC 1", ylab="PC 2")
title("PCA of Maize collection - 218 entries\naxes 1-2")
abline(v=0,h=0,col="grey", lty=2)

colorplot(pca.Maize$li[c(1,3)], pca.Maize$li, transp=TRUE, cex=3, xlab="PC 1", ylab="PC 3")
title("PCA of Maize collection - 218 entries\naxes 1-3")
abline(v=0,h=0,col="grey", lty=2)

## Identify groups using kmeans algorithm
## Kmeans :
grp1 <- find.clusters(dataGenet, max.n.clust = 35, n.pca = 150,
                      choose.n.clust = FALSE, criterion = "min",
                      n.start = 10)
grp1
( NbGroups <- length(levels(grp1$grp)) )

# to draw using ggplot  
bic <- data.frame(K = seq(1:35), bic = grp1$Kstat)

x11()
(BIC1 <- ggplot(bic, aes(x = K, y = bic)) +
    geom_line( color = "firebrick", size = 1.2))


## DAPC
## We want to assess the relationships between these groups using DAPC.

dapc1 <- dapc(dataGenet, pop = grp1$grp, scale = FALSE, n.pca = 100, n.da=4)

x11()
scatter(dapc1, scree.da = FALSE, bg="white",
        pch=20, cell=0, cstar = 0, col = seasun(12), solid =.6,
        cex=3,clab=0, leg=TRUE, txt.leg=paste("Cluster", 1:NbGroups))
points(dapc1$grp.coord[, 1], dapc1$grp.coord[, 2], col = 'black', pch = 20, cex = .5)
text(dapc1$grp.coord[, 1], dapc1$grp.coord[, 2], paste('group', 1:NbGroups, sep = ''))

x11()
scatter(dapc1, xax= 2, yax = 3,
        scree.da = FALSE, bg="white",
        pch=20, cell=0, cstar=0, col=seasun(12), solid=.6,
        cex=3,clab=0, leg=TRUE, txt.leg=paste("Cluster",1:NbGroups))
points(dapc1$grp.coord[, 2], dapc1$grp.coord[, 3], col = 'black', pch = 20, cex = .5)
text(dapc1$grp.coord[, 2], dapc1$grp.coord[, 3], paste('group',1:NbGroups, sep=''))


# ## For the fun: 
# library(plotly)
# x11()
# plot_ly(x = dapc1$grp.coord[, 1],
#         y = dapc1$grp.coord[, 2], 
#         z = dapc1$grp.coord[, 3],
#         type="scatter3d", mode="markers" )



## ------------  we can also perform hierarchical clustering to identify the groups


## -----------  Go with core collection  -----------  ##
##
## we will use a 'M-strategy" : evaluate hundreds of possible core-collections and single out one the one that maximize/minimize our criteria - we will vary the criteria
## the main achievement of the core hunter algorithm is to implement methods to "identify" hundreds of possible core collections
##
##
## another approach is:
## 1. to stratify the collection (pop. structure + other criteria) into clusters
## 2. to use the appropriate allocation method to determine the number of accessions to be drawn from each cluster. For example D-allocation method
## 3. possibly use corehunter to identify a representative set of accessions for each cluster
## we will NOT develop this strategy in this script



#----------------  default size, maximize entry-to-nearest-entry Modified Rogers distance
obj <- objective("EN", "MR")
## three independent runs
corea <- sampleCore(data, obj) ; length(corea$sel)
coreb <- sampleCore(data, obj) ; length(coreb$sel)
corec <- sampleCore(data, obj) ; length(corec$sel)

## comparisons using Venn
x1 <- list(
  default1 = corea$sel,
  default2 = coreb$sel,
  default3 = corec$sel
)

x11()
ggvenn(
  x1, 
  fill_color = c("#0073C2FF", "#EFC000FF", "#868686FF", "#CD534CFF"),
  stroke_size = 0.5, set_name_size = 4
)

# a dataframe to collect results
toto <- data.frame(dapc1$ind.coord)
toto$Group <- dapc1$assign
toto$ids <- seq(1:218)
toto$ccDF1 <- ifelse(toto$ids %in% corea$sel, 1,0)
toto$ccDF2 <- ifelse(toto$ids %in% coreb$sel, 1,0)
toto$ccDF3 <- ifelse(toto$ids %in% corec$sel, 1,0)

# long format for graphics
toto2 <- toto %>%
  pivot_longer(
    cols = starts_with("cc"),
    names_to = "Objective",
    values_to = "CoreColl",
    values_drop_na = TRUE
  )

x11()
( graf1 <- ggplot(toto2) + aes( x = LD1, y = LD2, color = factor(Group), group = factor(CoreColl)) +
  geom_point(aes(shape = factor(CoreColl), size = factor(CoreColl), alpha = factor(CoreColl) )) +
    scale_shape_manual(values = c(19, 18)) +
    scale_size_manual(values = c(2,4.5)) +
    scale_alpha_manual(values = c(0.25, 1)) +
    facet_wrap(~ Objective) +
    theme_bw()
)

x11()
( graf2 <- ggplot(toto2) + aes( x = LD2, y = LD3, color = factor(Group), group = factor(CoreColl)) +
    geom_point(aes(shape = factor(CoreColl), size = factor(CoreColl), alpha = factor(CoreColl) )) +
    scale_shape_manual(values = c(19, 18)) +
    scale_size_manual(values = c(2,4.5)) +
    scale_alpha_manual(values = c(0.25, 1)) +
    facet_wrap(~ Objective) +
    theme_bw()
)


# #----------------  absolute size, 
core3a <- sampleCore(data, obj, size = 96)  ## ie 1 PCR plate 
core3b <- sampleCore(data, obj, size = 96)  ## ie 1 PCR plate 
core3c <- sampleCore(data, obj, size = 96)  ## ie 1 PCR plate 
toto$ccAS1 <- ifelse(toto$ids %in% core3a$sel, 1, 0)
toto$ccAS2 <- ifelse(toto$ids %in% core3b$sel, 1, 0) 
toto$ccAS3 <- ifelse(toto$ids %in% core3c$sel, 1, 0) 

## comparisons using Venn
x3 <- list(
  defaultAS1 = core3a$sel,
  defaultAS2 = core3b$sel,
  defaultAS3 = core3c$sel
)


x11()
ggvenn(
  x3, 
  fill_color = c("#0073C2FF", "#EFC000FF", "#868686FF", "#CD534CFF"),
  stroke_size = 0.5, set_name_size = 4
)

# long format for graphics
toto3 <- toto %>%
  pivot_longer(
    cols = starts_with("ccAS"),
    names_to = "Objective",
    values_to = "CoreColl",
    values_drop_na = TRUE
  )

x11()
( graf3 <- ggplot(toto3) + aes( x = LD1, y = LD2, color = factor(Group), group = factor(CoreColl)) +
    geom_point(aes(shape = factor(CoreColl), size = factor(CoreColl), alpha = factor(CoreColl) )) +
    scale_shape_manual(values = c(19, 18)) +
    scale_size_manual(values = c(2,4.5)) +
    scale_alpha_manual(values = c(0.25, 1)) +
    facet_wrap(~ Objective) +
    theme_bw()
)


# #----------------  relative size
core4 <- sampleCore(data, obj, size = 0.1)
core4

# #----------------   multiple objectives (equal weight)
core5 <- sampleCore(data, obj = list(
  objective("EN", "MR"), ## use markers maximize entry-to-nearest-entry Modified Rogers distance - represent extremes
  objective("AN", "GD")  ## use phenotypes  with minimize accession-to-nearest-entry Gower Distance - represent individuals
))
core5 ; length(core5$sel)
toto$ccMO1 <- ifelse(toto$ids %in% core5$sel, 1, 0)


# #----------------  multiple objectives (custom weight)
core6 <- sampleCore(data, obj = list(
  objective("EN", "MR", weight = 0.3), ## use markers maximize entry-to-nearest-entry Modified Rogers distance - represent extremes
  objective("AN", "GD", weight = 0.7)   ## use phenotypes  with minimize accession-to-nearest-entry Gower Distance - represent individuals
))
core6 ; length(core6$sel)
toto$ccMO2 <- ifelse(toto$ids %in% core6$sel, 1, 0)

## comparisons using Venn
x4 <- list(
  MultObj1 = core5$sel,
  MultObj2 = core6$sel
)

x11()
ggvenn(
  x4, 
  fill_color = c("#0073C2FF", "#EFC000FF", "#868686FF", "#CD534CFF"),
  stroke_size = 0.5, set_name_size = 4
)


#----------------  results in the long format for graphics
# 
totoFull <- toto %>%
  pivot_longer(
    cols = starts_with("cc"),
    names_to = "Objective",
    values_to = "CoreColl",
    values_drop_na = TRUE
  )


### Core collections for multiple objectives
x11()
( graf10 <- totoFull %>% filter(Objective %in% c('ccMO1', 'ccMO2')) %>%
    ggplot() + aes( x = LD1, y = LD2, color = factor(Group), group = factor(CoreColl)) +
    geom_point(aes(shape = factor(CoreColl), size = factor(CoreColl), alpha = factor(CoreColl) )) +
    scale_shape_manual(values = c(19, 18)) +
    scale_size_manual(values = c(2,4.5)) +
    scale_alpha_manual(values = c(0.25, 1)) +
    facet_wrap(~ Objective) +
    theme_bw()
)


### ALL core collections:
x11()
( graf11 <- ggplot(totoFull) + aes( x = LD1, y = LD2, color = factor(Group), group = factor(CoreColl)) +
    geom_point(aes(shape = factor(CoreColl), size = factor(CoreColl), alpha = factor(CoreColl) )) +
    scale_shape_manual(values = c(19, 18)) +
    scale_size_manual(values = c(2,4.5)) +
    scale_alpha_manual(values = c(0.25, 1)) +
    facet_wrap(~ Objective) +
    theme_bw()
)