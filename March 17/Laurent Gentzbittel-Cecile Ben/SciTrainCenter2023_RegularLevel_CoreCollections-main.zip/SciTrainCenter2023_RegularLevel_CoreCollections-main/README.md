# Introduction to computing Core Collections

To get ready for the tutorials, please download/install the following software/R packages to your local machine

1. [R](https://www.r-project.org/) and [RStudio](https://www.rstudio.com/products/rstudio/download/)
2. R packages: [adegenet](https://cran.r-project.org/web/packages/adegenet/), [ggplot2](https://cran.r-project.org/web/packages/ggplot2), [corehunter](https://cran.r-project.org/web/packages/corehunter), [rJava](https://cran.r-project.org/web/packages/rJava), [ggvenn](https://cran.r-project.org/web/packages/ggvenn)


---
You may download the repository as a zip file to your own machine and appropriate folder: Use CODE / Download ZIP. After extraction, all elements will be in place.

Alternatively, you may download the data files, download or copy the scripts to your own machine and appropriate folder, and change the directory as needed to run the analysis.
