### OneMap is a software for constructing genetic maps in experimental crosses: 
### full-sib, RILs, F2, and backcrosses.  
### Margarido, G. R. A., Souza, A. P., &38; Garcia, A. A. F. (2007). OneMap: software for genetic mapping in outcrossing species. 
### Hereditas, 144(3), 78�79. https://doi.org/10.1111/j.2007.0018-0661.02000.x
### Tutorials: How to build a linkage map for inbred-bases populations (F2, RIL and BC):
### https://statgen-esalq.github.io/tutorials/onemap/Inbred_Based_Populations.html

### This is an example how to build a linkage map using F2 population of maize

# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())

library(onemap)

#Importing data
example_DH <- read_mapmaker(dir="D:/Onemap/RegularCourse", 
                                     file="barleyDH.raw")

#To see what this data set is about
example_DH

#visualization of the data
plot(example_DH)

#To find redundant markers
bins <- find_bins(example_DH, exact = FALSE)
bins

bins_example <- create_data_bins(example_DH, bins)
bins_example

#create a new input file with the data set you are working on after using these functions
write_onemap_raw(bins_example, file.name = "new_barley_dataset.raw")

#segregation test: do all the markers segregate as expected?
DH_test <- test_segregation(example_DH)
print(DH_test)

#calculating recombination frequency. By default LOD>3 and rec.frequency <0.5 are to declare linkage
twopts_DH <- rf_2pts(input.obj = example_DH)

print(twopts_DH)# the object is too complex to print

#here you can see the recombination fractions and LOD values 
print(twopts_DH, c("MWG858", "ABG358"))

#To assign markers to linkage groups, create a (un-ordered) sequence with all markers:
mark_DH <- make_seq(twopts_DH, "all")

#to discover linkage group: how markers can be grouped?
LGs_DH <- group(mark_DH)# by default LOD = 3, max.rf = 0.5
LGs_DH

(LGs_DH <- group(mark_DH, LOD = 1.9, max.rf = 0.5))


#the next step is to order the markers within each group
#mapping function we are going to use
set_map_fun(type = "haldane")

#let's start with LG1
LG1_DH <- make_seq(LGs_DH, 1)

#To order markers in this group, you can use a two-point based algorithm such as:
#Seriation (Buetow and Chakravarti, 1987), 
#Rapid Chain Delineation (Doerge, 1996), 
#Recombination Counting and Ordering (Van Os et al., 2005) 
#Unidirectional Growth (Tan and Fu, 2006):

LG1_rcd_DH <- rcd(LG1_DH, hmm = FALSE)# hmm (hidden Markov model) is applied here. Only recombination fractions are calculated
LG1_rec_DH <- record(LG1_DH, hmm = FALSE)
LG1_ug_DH <- ug(LG1_DH, hmm = FALSE)

#plot the recombination fraction matrix and LOD Scores based on a color scale 
#using the function rf_graph_table. This matrix can be useful to make some diagnostics about the map.

rf_graph_table(LG1_rcd_DH)
rf_graph_table(LG1_rec_DH)
rf_graph_table(LG1_ug_DH)

LG1_map_rcd <- map(LG1_rcd_DH) 
LG1_map_rec <- map(LG1_rec_DH)
LG1_map_ug <- map(LG1_ug_DH)

#Drawing the genetic map
maps_list <- list(LG1_rcd_DH)
draw_map(maps_list, names = TRUE, grid = TRUE, cex.mrk = 0.7)

#map just for one LG
draw_map(LG1_rcd_DH, names = TRUE, grid = TRUE, cex.mrk = 0.7)
# or
draw_map2(LG1_rcd_DH, group.names = c("LG1"), tag = c("ASE1A", "ABG058","MWG878","RbcS","BCD351F", "ABC156A" , "MWG858", "ABG358", "ABG459","Pox", "Adh8", "MWG557", "ABG316C", "ABC167B", "bBE54D", "CDO588", "MWG503" ,"Crg3A" ,"ABC252" ,"ABC157" ,"ABG316E" ,"ABC153" ,"Pcr1" ,"cMWG720" ,"bBE54C") ,
        output = "D:/Onemap/RegularCourse/LG1_rcd_DH.pdf")

