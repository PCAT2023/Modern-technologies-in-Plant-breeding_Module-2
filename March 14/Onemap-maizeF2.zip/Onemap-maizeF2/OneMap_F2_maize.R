### OneMap is a software for constructing genetic maps in experimental crosses: 
### full-sib, RILs, F2, and backcrosses.  
### Margarido, G. R. A., Souza, A. P., &38; Garcia, A. A. F. (2007). OneMap: software for genetic mapping in outcrossing species. 
### Hereditas, 144(3), 78�79. https://doi.org/10.1111/j.2007.0018-0661.02000.x
### Tutorials: How to build a linkage map for inbred-bases populations (F2, RIL and BC):
### https://statgen-esalq.github.io/tutorials/onemap/Inbred_Based_Populations.html

### This is an example how to build a linkage map using F2 population of maize

# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())

library(onemap)

#Importing data
example_f2 <- read_mapmaker(dir="D:/Onemap/RegularCourse", 
                                     file="maizeF2.raw")

#To see what this data set is about
example_f2

#visualization of the data
plot(example_f2)

#To find redundant markers
bins <- find_bins(example_f2, exact = FALSE)
bins

#segregation test: do all the markers segregate as expected?
f2_test <- test_segregation(example_f2)
print(f2_test)

#calculating recombination frequency. By default LOD>3 and rec.frequency <0.5 are to declare linkage
twopts_f2 <- rf_2pts(input.obj = example_f2)

print(twopts_f2)# the object is too complex to print

#here you can see the recombination fractions and LOD values for each possible phase
print(twopts_f2, c("Mk01_04", "Mk01_05"))

#To assign markers to linkage groups, create a (un-ordered) sequence with all markers:
mark_all_f2 <- make_seq(twopts_f2, "all")

#to discover linkage group: how markers can be grouped?
LGs_f2 <- group(mark_all_f2)
LGs_f2

#the next step is to order the markers within each group
#mapping function we are going to use
set_map_fun(type = "kosambi")

#let's start with LG1
LG1_f2 <- make_seq(LGs_f2, 1)

#To order markers in this group, you can use a two-point based algorithm such as:
#Seriation (Buetow and Chakravarti, 1987), 
#Rapid Chain Delineation (Doerge, 1996), 
#Recombination Counting and Ordering (Van Os et al., 2005) 
#Unidirectional Growth (Tan and Fu, 2006):

LG1_rcd_f2 <- rcd(LG1_f2, hmm = FALSE)# hmm (hidden Markov model) is not applied here. We use recombination frequency information only
LG1_rec_f2 <- record(LG1_f2, hmm = FALSE)
LG1_ug_f2 <- ug(LG1_f2, hmm = FALSE)
LG1_mds_f2 <- mds_onemap(input.seq = LG1_f2, hmm = F)

#plot the recombination fraction matrix and LOD Scores based on a color scale 
#using the function rf_graph_table. This matrix can be useful to make some diagnostics about the map.

rf_graph_table(LG1_rcd_f2)

# it is feasible to compare the multipoint likelihood of all possible orders between markers (exhaustive search)
# however, even with 7 or more markers it will take a couple of hours
# thus, we will randomly take 5 markers and calculate the multipoint likelihood of all possible orders
# Next, try to map the remaining markers, one at a time
# this procedure is automated in function 'order_seq'

LG1_f2_ord <- order_seq(input.seq = LG1_rcd_f2, n.init = 5,
                        subset.search = "twopt",
                        twopt.alg = "rcd", THRES = 3)

#what is the best marker order?
LG1_f2_ord

#To get the safe order
LG1_f2_safe <- make_seq(LG1_f2_ord, "safe")
LG1_f2_safe

#To get all markers to be included
LG1_f2_all <- make_seq(LG1_f2_ord, "force")
LG1_f2_all

#how the RF looks like?
rf_graph_table(LG1_f2_all)

#Drawing the genetic map
maps_list <- list(LG1_f2_all)
draw_map(maps_list, names = TRUE, grid = TRUE, cex.mrk = 0.7)

#map just for one LG
draw_map(LG1_f2_all, names = TRUE, grid = TRUE, cex.mrk = 0.7)
# or
draw_map2(LG1_f2_all, group.names = c("LG1"), output = "D:/Onemap/RegularCourse/LG1_f2_all.pdf")

## Export estimated progeny haplotypes
# progeny phased haplotypes estimated by OneMap HMM (hidden markov model).

# If 'most_likely = TRUE' the most likely genotype receives 1 and the rest 0 (if there are two most likely both receive 0.5), 
# if 'most_likely = FALSE' genotypes probabilities will be according to the HMM results.

(progeny_haplot <- progeny_haplotypes(LG1_f2_all, most_likely = FALSE, ind = 2, group_names = "LG1_final"))

plot(progeny_haplot, position = "stack")
plot(progeny_haplot, position = "split")


(progeny_haplot <- progeny_haplotypes(LG1_f2_all, most_likely = TRUE, ind = 2, group_names = "LG1_final"))

plot(progeny_haplot, position = "stack")
plot(progeny_haplot, position = "split")
