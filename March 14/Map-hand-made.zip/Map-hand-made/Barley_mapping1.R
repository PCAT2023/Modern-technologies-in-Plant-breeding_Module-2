### III. Initialization of the working space
# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())

#install.packages("qtl")
library(qtl)

barley <- read.cross ("csvr", "D:/RegularCourse-October2022/Sent-1", "Barley_map.csv", na.strings="na",
                      genotypes=c("AA","BB"),
                      alleles=c("A","B"), estimate.map=TRUE)

summary(barley)

plotMissing(barley)
#par(mfrow=c(1,2), las=1)
plot(ntyped(barley), ylab="No. typed markers", main="No. genotypes by individual")
plot(ntyped(barley, "mar"), ylab="No. typed individuals", main="No. genotypes by marker")

#############
#####Calculating genetic distances
newmap <- est.map(barley, chr = 1, map.function = "kosambi")

plotMap(barley, newmap)
barley <- replace.map(barley, newmap)
head(barley)
summaryMap(barley)


#### investigate the map: estimate pairwise recombination fractions
barley <- est.rf(barley)

plotRF(barley)
checkAlleles(barley, threshold=5)
rf <- pull.rf(barley)
lod <- pull.rf(barley, what="lod")
plot(as.numeric(rf), as.numeric(lod), xlab="Recombination fraction", ylab="LOD score")

