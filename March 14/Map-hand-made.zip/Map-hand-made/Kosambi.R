#How convert recombination frequencies between 25 markers of 30 DH lines of barley into genetic distances using Kosambi mapping function
#Mapping Function Kosambi (1943)

### III. Initialization of the working space
# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())


rAB <- 0.1333
x <- 1+2*rAB
x
y <- 1-2*rAB
y
ratio <- x/y
ratio
##log() by default computes the natural logarithms (Ln, with base e):
data <- 0.25*log(ratio)
data

rAB <- c (0.000,0.133,0.033,0.000,0.033,0.133,0.033,0.033,0.033,0.033,0.133,0.067,0.033,0.067,0.033,0.200,0.133,0.233,0.100,0.100,0.000,0.000,0.067,0.033)

for (val in rAB) {
  x <- 1+2*rAB
  y <- 1-2*rAB
  ratio <- abs(x/y)
  data <- 0.25*log(ratio)
} 
  print(data)
  
sum(data)


