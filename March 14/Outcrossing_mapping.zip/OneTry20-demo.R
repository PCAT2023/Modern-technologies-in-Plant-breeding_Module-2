## Construction of Genetic Maps in Experimental Crosses for outcrossing species
## Statistical analysis by simultaneously estimating linkage and linkage phases 
## (genetic map construction) according to Wu et al. (2002) <doi:10.1006/tpbi.2002.1577>. 
## All analysis are based on multipoint approaches using hidden Markov models.

### Initialisation of the working space
# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())

library(onemap)

#read vcf file
data <-onemap_read_vcfR(
  vcf = "C:/Users/e.potokina/Documents/Onemap/dixie_on_noble_LG20.vcf",
  cross = "outcross",
  parent1 = "Dixi_Rod_rep3",
  parent2 = "Dixi_Rod_rep4",
  f1 = NULL,
  only_biallelic = TRUE,
  output_info_rds = NULL,
  verbose = TRUE
)

print(data)
head(data)

x11()
plot(data, all = TRUE)

#The first step is estimating the recombination fraction between all pairs of markers, 
#using two-point tests.

twopts <- rf_2pts(data) #Performs the two-point (pairwise) analysis proposed by Wu et al. (2002) between all pairs of markers.

#all our markers with no distortion (1:2:1), so, take them all
LG20 <- make_seq(twopts, c("all")) #trying to find the best linkage phases

#######################################################
#First of all, you must set the mapping function 
#that should be used to display the genetic map throughout the analysis
set_map_fun(type = "kosambi")


#In this sample we have just one linkage group - LG20
#'map' function estimates the multipoint log-likelihood, 
#linkage phases and recombination frequencies for a sequence of markers in a given order.

LG20.map <- map(LG20) 

#To recover parents' haplotypes
parents_haplot <- parents_haplotypes(LG20.map)
parents_haplot # "a" and "b" correspond to alternative and reference allele
write.table(parents_haplot, "parents_haplotypes_LG20.txt")

#To recover progeny haplotypes
#Plot recombination breakpoints counts for each individual
progeny_S10 <- progeny_haplotypes(LG20.map, most_likely = FALSE, ind = c(1), group_names = "20")
progeny_S10
write.table(progeny_S10, "progeny_haplotypes_S10.txt")

progeny_S100 <- progeny_haplotypes(LG20.map, most_likely = FALSE, ind = c(2), group_names = "20")
progeny_S100
write.table(progeny_S100, "progeny_haplotypes_S100.txt")

progeny_S11 <- progeny_haplotypes(LG20.map, most_likely = FALSE, ind = c(5), group_names = "20")
progeny_S11
write.table(progeny_S11, "progeny_haplotypes_S11.txt")

progeny_haplotypes(LG20.map)
write.table(progeny_mapLG20, "progeny_haplotypes_LG20.txt")

#Graphics to visualize the progeny S_10 haplotypes - no recombination
x11()
plot(progeny_S10, position = "split")

x11()
plot(progeny_S10, position = "stack")

#Graphics to visualize the progeny S_11 haplotypes - there was a recombination event
x11()
plot(progeny_S11, position = "split")
x11()
plot(progeny_S11, position = "stack")






