# Barley data set 

• All data available from http://triticeaetoolbox.org/barley/  
• Data from replicated yield trial, 768 lines  
• Trait is grain protein content, important in malting/brewing  

• HapMap_Genotypes – data in HapMap format  
• Protein – protein content of grain in %  
• 2359 markers on seven chromosomes  
• Missing data was set at 20% i.e. markers missing more than 20% were removed  

