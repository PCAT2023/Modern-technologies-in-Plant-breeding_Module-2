### Example data for tutorial
30K SNPs for chromosome 3 and chromosome 7 of *Medicago truncatula*.   see http://www.medicagohapmap.org/

The traits analysed in approx 290 accessions are :  
*  the Root Rot Index (RRI) in response to infection by *Aphanomyces euteiches*.  (Bonhomme *et al.* 2014. New Phytologist 201, 1328–1342)

*  the pod coiling sense. (*unpublished data*)

