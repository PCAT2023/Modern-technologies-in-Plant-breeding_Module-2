#' ---
#' title:  |
#'   | A first step into GWAS  
#'   | naive GLM and basics of MLM analyses
#' author:
#'   - Prof C. Ben, Project Center for Agro Technologies, Skoltech ^[c.ben@skoltech.ru]
#'   - Prof L. Gentzbittel, Project Center for Agro Technologies, Skoltech ^[l.gentzbittel@skoltech.ru]
#' date: "March 2023, Skoltech"
#' output: 
#'   rmdformats::readthedown:
#'     highlight: haddock
#'   pdf_document:
#'     keep_tex: true
#' use_bookdown: TRUE
#' latex_engine: xelatex
#' header-includes:
#'   - \usepackage{bbold}
#'   - \def\+#1{\mathbf{#1}}
#' geometry: left = 2cm, right = 1.5cm, top = 1.5cm, bottom = 1.5cm
#' ---
#'  
#' 
#+ echo = FALSE, message = FALSE, warning = FALSE
# just forgot the below lines. They are used to generate the printed version
knitr::opts_chunk$set(fig.width = 4.5, fig.height = 4.5, fig.align = "center",
                      warning = FALSE, message = FALSE,
                      tidy.opts = list(width.cutoff = 75), tidy = FALSE
)

# just forgot the below lines. They are used to generate the printed version OR the html version
# library(rmarkdown)
# render('01.GAPIT_GLM-MLM1.R',output_format = 'pdf_document')
# render('01.GAPIT_GLM-MLM1.R',output_format = 'html_document')


######### CASE STUDY PRESENTATION #############################################
### 
#' GWAS for quantitative disease resistance in Medicago truncatula for Aphanomyces euteiches.  
#' Analysis of Root rot index after infection. Data collected using Augmented Block Design


######### PREPARATION OF THE WORKING INTERFACE IN R ###########################
### I. Set working directory
#On RStudio: tab 'Session'-> Set Working Directory -> Choose Directory.
#Choose the directory containing the R script.

### II. Installation R packages needed for the analysis on RStudio:
#Click on the 'Packages' tab in the bottom-right window of R Studio interface->'Install Packages'
#Comment #1: R package installation requires a connection to internet
#Comment #2: Once packages have been installed, NO need to re-install them again 
# when you close and open again RStudio.

### III. Initialisation of the working space:clean workspace, clean memory 
# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())
# garbage collector. To use to free memory
gc() 

# to run GAPIT we need to access some tools that are located in other packages. The following lines of 
# code will install the required packages in to your R library and then will import them so that GAPIT
# may access them. The easiest way to do this is to highlight all of the following code and select run. 
# Once you have done this, you will only need to use the library functions to access them at future dates.


# if (!requireNamespace("BiocManager", quietly = TRUE))
#   install.packages("BiocManager")
# BiocManager::install("multtest")  ## may produce error if already installed - DO not stress.
# 
## required packages. Install if not installed
packages <- c('gplots','LDheatmap','genetics')
install.packages(setdiff(packages, rownames(installed.packages())))

library("multtest")
library("gplots")
# library("LDheatmap")
library("genetics")
library("compiler") #this library is already installed in R


## folder for scripts and main files
main_dir <- here::here()
setwd(main_dir)


################################################################################
# METHOD 1 TO INSTALL GAPIT
# install sources of GAPIT from internet -- WARNING ; CURRENT VERSION IS NOT WORKING PROPERLY
# source("http://zzlab.net/GAPIT/GAPIT.library.R")    ## line commented out on 2022, Oct 17th
# source("http://zzlab.net/GAPIT/gapit_functions.txt")  ## Thanks to Alexey Zamalutdinov !!
## at first run, several packages may be installed automatically
################################################################################

################################################################################
# METHOD 2 TO INSTALL GAPIT
# install GAPIT from Github
# install.packages("devtools")
# devtools::install_github("jiabowang/GAPIT3",force=TRUE)
# library(GAPIT3)
################################################################################

################################################################################
#### DO NOT MIX BOTH METHODS : USE METHOD 1 or METHOD 2
################################################################################

################################################################################
# METHOD 3 TO USE GAPIT
# to prevent issue with internet connexion, we provide you with the file of Gapit functions
##  !!!!!!!!!!!!!!!  to avoid issues  !!!!!!!!!!!!!!!!!!!!!!!
source(paste(main_dir,"/gapitV3_functions-2023.txt", sep=''))  ##
##  !!!!!!!!!!!!!!!  to avoid issues  !!!!!!!!!!!!!!!!!!!!!!!
################################################################################


## indicate here the folder where are located the data
## and subdirs where outputs will be stored during analyses
setwd(paste(main_dir, "./data1/", sep=""))


################################################################################
##
## the default model for GAPIT is CMLM w/o P3D, using 3 PCAs and vanRaden 
## kinship for groups defined with optimum compression level.
## It is already a sophisticated model
##
################################################################################


# load phenotype and genotype data in HapMap format

myY <- read.table("AphanoRRI_GapIt.csv", header = TRUE)
head(myY)

# myG <- read.table("240K_chr3.hmp.GAPIT.txt", header = FALSE) 
myG <- read.table("240Kupdated_chr3.hmp.txt", header = FALSE) 
head(myG)
## caution!!  no character '#' within your data files !


myCV <- read.table("MtrPopStruct_Admixture_K8.csv", header = TRUE )
head(myCV)
myKid <- read.table("KinshipMatrix_Identity.txt", header = FALSE )
head(myKid)
# myKI1 <- read.table("KinshipMatrix_V4SelectedSNPs-40K.txt", header = FALSE )
# head(myKI1)
myKI2 <- read.table("KinshipMatrix_V4SelectedSNPs-840K.txt", header = FALSE )
head(myKI2)


# #---------------------------------------------------------------------------
# GLM: the first method.  Need to include correction for pop. structure
# #---------------------------------------------------------------------------

## indicate here the folder where results will be written
dir.create(file.path(main_dir, "data1/GLM0"))          # Create new folder
setwd(file.path(main_dir, "data1/GLM0"))

# run GWAS with naive GLM
myGAPIT_GLM0 <- GAPIT(
  Y = myY[, 1:2],
  G = myG,
  SNP.MAF = 0.05,
  SNP.fraction = 0,  ## NO kinship
  PCA.total = 0, ## no pop struct
  Model.selection = FALSE,
  model = "GLM",
  Geno.View.output = FALSE  ## required when too much SNPs
)


##
# run GWAS with GLM and pop structure given by PCA internally computed

## indicate here the folder where results will be written
dir.create(file.path(main_dir, "data1/GLM1"))          # Create new folder
setwd(file.path(main_dir, "data1/GLM1"))

myGAPIT_GLM1 <- GAPIT(
  Y = myY[, 1:2],
  G = myG,
  SNP.MAF = 0.02,
  SNP.fraction = 0,  ## NO kinship
  PCA.total = 3,  ## pop structure based on 3 PCAs 
  Model.selection = FALSE,
  model = "GLM",
  Geno.View.output = FALSE  ## required when too much SNPs
)


##
# run GWAS with GLM and pop structure given by Admixture

## indicate here the folder where results will be written
dir.create(file.path(main_dir, "data1/GLM2"))          # Create new folder
setwd(file.path(main_dir, "data1/GLM2"))

myGAPIT_GLM2 <- GAPIT(
  Y = myY[, 1:2],
  G = myG,
  SNP.MAF = 0.02,
  SNP.fraction = 0,  ## NO kinship
  PCA.total = 0,  
  CV = myCV[, 1:7],         ## pop. structure given by admixture components
  Model.selection = FALSE,
  model = "GLM",
  Geno.View.output = FALSE  ## required when too much SNPs
)

# #----------------------------------------------------------------------------
# # MLM : the basic 'gold standard'; including pop. structure and kinship
# # and various tricks to speed-up computations P3D, EMMAX, CMLM
# #----------------------------------------------------------------------------

# run GWAS with naive MLM : no pop struct and kinship = identity
# P3D used by default
## indicate here the folder where results will be written
dir.create(file.path(main_dir, "data1/MLM0"))          # Create new folder
setwd(file.path(main_dir, "data1/MLM0"))

myGAPIT_MLM0 <- GAPIT(
  Y = myY[, 1:2],
  G = myG,
  SNP.MAF = 0.02,
  KI = myKid,  
  PCA.total = 0, ## no pop struct
  Model.selection = FALSE,
  model = "MLM",
  Geno.View.output = FALSE  ## required when too much SNPs
)


# run GWAS with  MLM : including pop struct and kinship = identity
# P3D used by default
## indicate here the folder where results will be written
dir.create(file.path(main_dir, "data1/MLM1"))          # Create new folder
setwd(file.path(main_dir, "data1/MLM1"))

myGAPIT_MLM1 <- GAPIT(
  Y = myY[, 1:2],
  G = myG,
  SNP.MAF = 0.02,
  KI = myKid,  ## indicate here the kinship matrix used
  PCA.total = 3, 
  Model.selection = FALSE,
  model = "MLM",
  Geno.View.output = FALSE  ## required when too much SNPs
)


# run GWAS with  MLM : both  pop struct and kinship computed by GAPIT
# P3D used by default

dir.create(file.path(main_dir, "data1/MLM2"))          # Create new folder
setwd(file.path(main_dir, "data1/MLM2"))

myGAPIT_MLM2 <- GAPIT(
  Y = myY[, 1:2],
  G = myG,
  SNP.MAF = 0.02,
  PCA.total = 3,   ## note that KI is not specified because it computed by default
  Model.selection = FALSE,
  model = "MLM",
  Geno.View.output = FALSE  ## required when too much SNPs
)


# run GWAS with MLM : including pop struct and kinship 40K computed before
# P3D used by default

# dir.create(file.path(main_dir, "data1/MLM3a"))          # Create new folder
# setwd(file.path(main_dir, "data1/MLM3a"))
# 
# myGAPIT_MLM3a <- GAPIT(
#   Y = myY[, 1:2],
#   G = myG,
#   SNP.MAF = 0.02,
#   KI = myKI1,     ## provided by user
#   PCA.total = 3,  ## computed by GaPit
#   Model.selection = FALSE,
#   model = "MLM",
#   Geno.View.output = FALSE  ## required when too much SNPs
# )


# run GWAS with MLM : including both pop struct and kinship 840K computed before
# P3D used by default

dir.create(file.path(main_dir, "data1/MLM3b"))          # Create new folder
setwd(file.path(main_dir, "data1/MLM3b"))

myGAPIT_MLM3b <- GAPIT(
  Y = myY[, 1:2],
  G = myG,
  SNP.MAF = 0.02,
  KI = myKI2,  ## provided by user
  CV = myCV,   ## provided by user
  Model.selection = FALSE,
  model = "MLM",
  Geno.View.output = FALSE  ## required when too much SNPs
)


# #----------------------------------------------------------------------------
# # CMLM : a modification of MLM to speed up and possibly improve 
# # information provided by the kinship
# #  P3D enabled by default
# #----------------------------------------------------------------------------

# run CMLM, compute 'best number of groups' automagically

dir.create(file.path(main_dir, "data1/CMLM1"))          # Create new folder
setwd(file.path(main_dir, "data1/CMLM1"))

myGAPIT_CMLM1 <- GAPIT(
  Y = myY[, 1:2],
  G = myG,
  SNP.MAF = 0.02,
  kinship.algorithm = "Vanraden",  ## formula to compute kinship matrix  
  PCA.total= 5,    ## population structure computed by Gapit
  Model.selection = TRUE,  ## optimal num of PC and groups for kinship     
  model = "CMLM",
  ## Random.model=TRUE,  ## to get PVE(phenotype variance explained) 
  ## with the significant markers. Does NOT work ?!?
  group.from = 1, group.to = 1000, ### >n accessions -> so max num
  group.by = 20,   
  kinship.cluster = "average",
  kinship.group= "Max",
  Geno.View.output = FALSE  ## required when too much SNPs
)


# run CMLM, force to only two groups

dir.create(file.path(main_dir, "data1/CMLM2"))          # Create new folder
setwd(file.path(main_dir, "data1/CMLM2"))

myGAPIT_CMLM2 <- GAPIT(
  Y = myY[, 1:2],
  G = myG,
  SNP.MAF = 0.02,
  kinship.algorithm = "Vanraden",  ## formula to compute kinship matrix  
  PCA.total= 5,    ## population structure computed by Gapit
  Model.selection = FALSE,     
  model = "CMLM",
  group.from = 2, group.to = 2, ### force only two groups to exemplifies method
  group.by = 1,   
  kinship.cluster = "average",
  kinship.group= "Mean",
  Geno.View.output = FALSE  ## required when too much SNPs
)


# #----------------------------------------------------------------------------
## TO COMPARE SEVERAL METHODS
# #----------------------------------------------------------------------------

dir.create(file.path(main_dir, "data1/Compare"))          # Create new folder
setwd(file.path(main_dir, "data1/Compare"))

## also import SNPs from two different chromosomes.
# For the Hapmap format. the common file name (e.g. # "mdp_genotype_chr"), 
# file name extension (e.g. "hmp.txt") are passed to GAPIT through 
## the "file.G", and  # "file.Ext.G" parameters
## The starting file and the ending file are specified by file.from 
## and file.to parameters. 

myGAPIT_Compare <- GAPIT(
  Y = myY[, 1:2],
  ##  G = myG,
  file.path = paste(main_dir, "./data1/", sep=""),
  file.G = "240K_chr",
  file.Ext.G = "hmp.GAPIT.txt",  ## note: the first "." is not indicated
  file.from = 3,
  file.to = 7,
  
  SNP.MAF = 0.05, 
  kinship.algorithm = "EMMA",  ## formula to compute kinship matrix  
  PCA.total = 5,    ## population structure computed by Gapit
  # Model.selection = TRUE,   ##     
  model = c("GLM","MLM", 'CMLM'),
  # group.from = 1, group.to = 1000, 
  # group.by = 20,   
  kinship.cluster = "average",
  kinship.group= "Mean",
  Multiple_analysis = TRUE,  ## to comparatively vizualise results
  ## Random.model = TRUE,  ## does not work if some genotyped samples are not 
  ## phenotyped !
  Geno.View.output = FALSE  ## required when too much SNPs
)


# #----------------------------------------------------------------------------
## TO MAP QUALITATIVE TRAITS
# #----------------------------------------------------------------------------

setwd(file.path(main_dir,"/data1"))
myY <- read.table("PodCoiling_GapIt.csv", header = TRUE)
head(myY)


dir.create(file.path(main_dir, "data1/PodCoiling"))          # Create new folder
setwd(file.path(main_dir, "data1/PodCoiling"))


myGAPIT_Coiling <- GAPIT(
  Y = myY[, 1:4],
  ##  G = myG,
  file.path = paste(main_dir, "./data1/", sep=""),
  file.G = "240K_chr",
  file.Ext.G = "hmp.GAPIT.txt",  ## note: the first "." is not indicated
  file.from = 3,
  file.to = 7,
  
  SNP.MAF = 0.05, 
  kinship.algorithm = "EMMA",  ## formula to compute kinship matrix  
  PCA.total = 5,    ## population structure computed by Gapit
  model = "MLM",
  Multiple_analysis = TRUE,  ## to comparatively visualize results
  Geno.View.output = FALSE  ## required when too much SNPs
)

# #----------------------------------------------------------------------------
## Manhattan plots using qqman package
# #----------------------------------------------------------------------------

library(qqman)
## if not satisfied by qqman::manhattan() defaults, it is easy to modify it to
## fit your needs.


PodCoiling  <- read.table("GAPIT.Association.GWAS_Results.MLM.PodCoiling.csv",  sep = ",", header=TRUE)
PodCoiling2 <- read.table("GAPIT.Association.GWAS_Results.MLM.PodCoiling2.csv", sep = ",", header=TRUE)
PodCoiling3 <- read.table("GAPIT.Association.GWAS_Results.MLM.PodCoiling3.csv", sep = ",", header=TRUE)

x11()
par(mfrow=c(3,1))  ## three sub-figures in one graph
manhattan(
  PodCoiling,
  chr = "Chr",
  bp = "Pos",
  p = "P.value",
  snp = "SNP",
  main = "Pod Coiling, encoding 1",
  col = c("orange3", "blue4"),
  chrlabs = "chrom.",
  suggestiveline = -log10(1e-05),
  genomewideline = -log10(5e-08),
  highlight = NULL,
  logp = TRUE,
  annotatePval = NULL,
  annotateTop = TRUE
)
manhattan(
  PodCoiling2,
  chr = "Chr",
  bp = "Pos",
  p = "P.value",
  snp = "SNP",
  main = "Pod Coiling, encoding 2",
  col = c("orange3", "blue4"),
  chrlabs = NULL,
  suggestiveline = -log10(1e-05),
  genomewideline = -log10(5e-08),
  highlight = NULL,
  logp = TRUE,
  annotatePval = NULL,
  annotateTop = TRUE
)
manhattan(
  PodCoiling3,
  chr = "Chr",
  bp = "Pos",
  p = "P.value",
  snp = "SNP",
  main = "Pod Coiling, encoding 3",
  col = c("orange3", "blue4"),
  chrlabs = NULL,
  suggestiveline = -log10(1e-05),
  genomewideline = -log10(5e-08),
  highlight = NULL,
  logp = TRUE,
  annotatePval = NULL,
  annotateTop = TRUE
)


