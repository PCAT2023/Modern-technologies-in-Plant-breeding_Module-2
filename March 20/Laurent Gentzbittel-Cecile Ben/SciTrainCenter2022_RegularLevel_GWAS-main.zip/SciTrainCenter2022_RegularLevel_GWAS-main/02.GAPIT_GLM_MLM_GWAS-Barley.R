#' ---
#' title:  |
#'   | A deeper step into GWAS :  
#'   | CMLM analyses and beyond ...
#' author:
#'   - Prof C. Ben, Project Center for Agro Technologies, Skoltech ^[c.ben@skoltech.ru]
#'   - Prof L. Gentzbittel, Project Center for Agro Technologies, Skoltech ^[l.gentzbittel@skoltech.ru]
#' date: "March 2023 - MSC Life Sciences 2023"
#' output: 
#'   rmdformats::readthedown:
#'     highlight: haddock
#'   pdf_document:
#'     keep_tex: true
#' use_bookdown: TRUE
#' latex_engine: xelatex
#' header-includes:
#'   - \usepackage{bbold}
#'   - \def\+#1{\mathbf{#1}}
#' geometry: left = 2cm, right = 1.5cm, top = 1.5cm, bottom = 1.5cm
#' ---
#'  
#' 
#+ echo = FALSE, message = FALSE, warning = FALSE
# just forgot the below lines. They are used to generate the printed version
knitr::opts_chunk$set(fig.width = 4.5, fig.height = 4.5, fig.align = "center",
                      warning = FALSE, message = FALSE,
                      tidy.opts = list(width.cutoff = 75), tidy = FALSE
)
 
# just forgot the below lines. They are used to generate the printed version OR the html version
# library(rmarkdown)
# render('01.GAPIT_GLM-MLM1.R',output_format = 'pdf_document')
# render('01.GAPIT_GLM-MLM1.R',output_format = 'html_document')

#+ echo = TRUE, message = TRUE, warning = FALSE 


######### PREPARATION OF THE WORKING INTERFACE IN R ###########################
### I. Set working directory
#On RStudio: tab 'Session'-> Set Working Directory -> Choose Directory.
#Choose the directory containing the R script.

### II. Installation R packages needed for the analysis on RStudio:
#Click on the 'Packages' tab in the bottom-right window of R Studio interface->'Install Packages'
#Comment #1: R package installation requires a connection to internet
#Comment #2: Once packages have been installed, NO need to re-install them again 
# when you close and open again RStudio.

### III. Initialisation of the working space:clean workspace, clean memory 
# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())
# garbage collector. To use to free memory
gc() 


# to run GAPIT we need to access some tools that are located in other packages. The following lines of 
# code will install the required packages in to your R library and then will import them so that GAPIT
# may access them. The easiest way to do this is to highlight all of the following code and select run. 
# Once you have done this, you will only need to use the library functions to access them at future dates.

# if (!requireNamespace("BiocManager", quietly = TRUE))
#   install.packages("BiocManager")
# BiocManager::install("multtest")
# 

## required packages. Install if not installed
packages <- c('gplots','LDheatmap','genetics')
install.packages(setdiff(packages, rownames(installed.packages())))

library("multtest")
library("gplots")
library("LDheatmap")
library("genetics")
library("compiler") #this library is already installed in R


## indicate here the folder where are located the data
## and subdirs where outputs will be stored

main_dir <- here::here() 
setwd(paste(main_dir, "./data2/", sep=""))


################################################################################
# METHOD 1 TO INSTALL GAPIT
# install sources of GAPIT from internet -- WARNING ; CURRENT VERSION IS NOT WORKING PROPERLY
# source("http://zzlab.net/GAPIT/GAPIT.library.R")    ## line commented out on 2022, Oct 17th
# source("http://zzlab.net/GAPIT/gapit_functions.txt")  ## Thanks to Alexey Zamalutdinov !!
## at first run, several packages may be installed automatically
################################################################################

################################################################################
# METHOD 2 TO INSTALL GAPIT
# install GAPIT from Github
# install.packages("devtools")
# devtools::install_github("jiabowang/GAPIT3",force=TRUE)
# library(GAPIT3)
################################################################################

################################################################################
#### DO NOT MIX BOTH METHODS : USE METHOD 1 or METHOD 2
################################################################################


################################################################################
# METHOD 3 TO USE GAPIT
# to prevent issue with internet connexion, we provide you with the file of Gapit functions
##  !!!!!!!!!!!!!!!  to avoid issues  !!!!!!!!!!!!!!!!!!!!!!!
source(paste(main_dir,"/gapitV3_functions-2023.txt", sep=''))  ##
##  !!!!!!!!!!!!!!!  to avoid issues  !!!!!!!!!!!!!!!!!!!!!!!
################################################################################



# Now we need to import the data files that we will be using for doing the analysis. 

hapmap_geno <- read.table("HapMap_genotypes.txt", header = F) # make sure header=F
pheno <- read.table("protein.txt", header = T)

# good idea to check our phenotype data to make sure the file structure is 
# correct and how the data is distributed, checking for outliers

str(pheno) # gives us information on the object, in this case a data frame and other information
x11()
hist(pheno$protein) # creates a histogram plot of our data, things look pretty good, we have a
 #lines that are bit extreme but with 775 lines we would expect about 27 to be at least 3 sd's away from
 # the mean. 

#some basic statistics to look at 
mean(pheno$protein) # 12.23
range(pheno$protein) # 9.5 to 15.8
sd(pheno$protein) # .88

which(is.na(pheno$protein)) # look for lines with missing data, there should 
                            # be none 
# This is confirmed by the result in the console "integer(0)" 
# meaning the number of NA values was 0



# #----------------------------------------------------------------------------
##   Basic and non basic CMLM model
# #----------------------------------------------------------------------------
# The compressed MLM model (CMLM) clusters the individuals into groups (several
# methods), compute the kinshinp among groups and  fits genetic values 
# of groups as random effects in the model.

# the following is a very basic analysis. Make sure to change directory to 
# where the results will be saved. 

dir.create(file.path(main_dir, "data2/noCMLM"))          # Create new folder
setwd(file.path(main_dir, "data2/noCMLM"))

# first analysis where compression is not used in the model, this is done by 
# setting the group.from 
# and group.to equal to the size of your population and then setting the group.
# by to 1 so that each 
# entry is consider its own "group." Again, refer to manual for complete 
# description.

analysis1<-GAPIT(
  Y = pheno,
  G = hapmap_geno,
  SNP.impute = "Major",
  SNP.MAF = 0.05,
  PCA.total = 5,  ## pop structure
  Major.allele.zero = T,  ## fix the major allele to have 0 
              ## Thus, the given effect is always relating to the minor allele.
  group.from = 768,
  group.to = 768,  ## WITHOUT compression method, computer computed kiship
  group.by = 1,
  Geno.View.output = FALSE  ## required when too much SNPs
  )


# now we use compression to see how that effects the outcome of the analysis. 
# The default settings for compression are to group by 10. You can change this 
# to whatever value you feel like. It is important to note that not all values 
# will work depending on your population. You will get the error that 
# "matrix is singular, select another level." You can keep selecting levels 
# until you find one  that works. However, compression may not make 
# that big of a difference for your analyses. To read more about it see 
# "Mixed linear model approach for genome-wide association studies" Zhang et al. 
# Nature Genetics 2010


# change the directory where the output will be stored
dir.create(file.path(main_dir, "data2/CMLM"))          # Create new folder
setwd(file.path(main_dir, "data2/CMLM"))


analysis2<-GAPIT(
  Y = pheno,
  G = hapmap_geno,
  SNP.impute = "Major",
  SNP.MAF = 0.05,
  PCA.total = 5,
  Model.selection = TRUE,  ## optimal num of PC and groups for kinship     
  model = "CMLM",
  ## Random.model=TRUE,  ## to get PVE(phenotype variance explained) 
  ## with the significant markers. Does NOT work ?!?
  group.from = 1, group.to = 1000, ### >n accessions -> so max num
  group.by = 30,   
  Major.allele.zero = T,
  Geno.View.output = FALSE  ## required when too much SNPs
  )

# the differences were pretty small   compare tables
# no compression used 
# SNP    FDR_Adjusted_P-values
# 12_10811  	1.74E-06
# 12_10199		1.74E-06
# 12_10575		1.74E-06
# 12_20685		1.75E-06
# 12_11437		1.17E-05
# 12_30301		0.000439948

# with compression
# SNP  	FDR_Adjusted_P-values
# 12_10811	1.60E-06
# 12_10199	1.60E-06
# 12_10575  1.60E-06
# 12_20685	2.36E-06
# 12_11437	1.40E-05
# 12_30301	0.000599332

## this is because NO grouping was found ! 
## This is a particular case were CMLM is NOT efficient 
##  using default values of methods **

# #----------------------------------------------------------------------------
##   The "most advanced" single locus model : SUPER
##   
# #----------------------------------------------------------------------------
# in SUPER model, only the associated genetic markers, instead of all 
# (or a random sampling) of the markers, are used as pseudo Quantitative Trait 
# Nucleotides (QTNs) to derive kinship (Wang et al., 2014). 
# Whenever a pseudo QTN is correlated with the testing marker, it is excluded 
# from those used to derive kinship. The SUPER model applies a threshold on *LD* 
# (not on physical distance) between the pseudo QTNs and the testing marker. 

# change the directory where the output will be stored
dir.create(file.path(main_dir, "data2/SUPER"))          # Create new folder
setwd(file.path(main_dir, "data2/SUPER"))

analysisSUPER <- GAPIT(
  Y = pheno,
  G = hapmap_geno,
  SNP.impute = "Major",
  PCA.total = 5,
  SNP.MAF = 0.05,
  Major.allele.zero = T,
  #Model.selection = TRUE,   ## does NOT work with SUPER
  model = "SUPER",
  Geno.View.output = FALSE,
  LD = 0.25,
  # Random.model = TRUE  ##  to get PEVs. Actually, this option does NOT work with gapitV3-2020
  Random.model = FALSE
)


# change the directory where the output will be stored
dir.create(file.path(main_dir, "data2/Compare"))          # Create new folder
setwd(file.path(main_dir, "data2/Compare"))

analysisSingleLocus <- GAPIT(
  Y = pheno,
  G = hapmap_geno,
  SNP.impute = "Major",
  PCA.total = 5,
  SNP.MAF = 0.05,
  Major.allele.zero = T,
  model = c("MLM", 'CMLM', "SUPER"),
  LD = 0.25,   ## criteria to excluded a QTN from kinship if close to testing marker
  Multiple_analysis = TRUE,  ## to comparatively visualise results
  Geno.View.output = FALSE,
  Random.model = FALSE
)
## As shown with previous analyses, MLM and CMLM results are identical  


# #----------------------------------------------------------------------------
##   Using multilocus model : FarmCPU
##   This is NOT a multitrait model
# #----------------------------------------------------------------------------



# change to a location that works for you
dir.create(file.path(main_dir, "data2/FarmCPU"))          # Create new folder
setwd(file.path(main_dir, "data2/FarmCPU"))


analysis4<-GAPIT(
  Y = pheno,
  G = hapmap_geno,
  SNP.impute = "Major",
  PCA.total = 15,
  Major.allele.zero = T, 
  SNP.MAF = 0.05,
  Random.model = FALSE,  ##  to get PEVs
  file.output = TRUE,
  Geno.View.output = FALSE,  ## required when too much SNPs
  model = "FarmCPU")

# Note : (May 2021) Based on the GAPIT development , Model.selection function
# is not available for new methods, such as FarmCPU, MLMM, and Blink.
# But if you want, you can use Model.selection to confirm the optimal number of 
# PCs in the mixed linear model (MLM) at first. Then put these PCs 
# into new model.

# change to a location that works for you
dir.create(file.path(main_dir, "data2/Compare2"))          # Create new folder
setwd(file.path(main_dir, "data2/Compare2"))

analysisCompareAll <- GAPIT(
  Y = pheno,
  G = hapmap_geno,
  SNP.impute = "Major",
  PCA.total = 15,
  SNP.MAF = 0.05,
  Major.allele.zero = T,
  model = c("MLM", "SUPER", "FarmCPU"),
  LD = 0.2,## criteria to excluded a QTN from kinship if close to testing marker
  Geno.View.output = FALSE,  ## required when too much SNPs
  Multiple_analysis = TRUE  ## to comparatively visualise results
)










