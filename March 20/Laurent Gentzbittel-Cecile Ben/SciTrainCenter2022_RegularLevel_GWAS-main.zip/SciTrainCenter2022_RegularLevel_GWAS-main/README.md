# Scientific Training Center for Plant Biotechnologies - "Regular" level, 2023 - GWAS


## Hands-on for sessions put together by Cecile Ben, Laurent Gentzbittel and colls.

The object of these hands-on sessions is to conduct GWAS with some published softwares, using several different dataset as examples. The choice of GWAS models ranges from the gold standard mixed linear model (MLM) to the fixed and random model circulating probability unification (FarmCPU). Highlighed in figure below (Fig. from [Cortes *et al.*](https://acsess.onlinelibrary.wiley.com/doi/full/10.1002/tpg2.20077))


<p align="center">
  <img src="https://github.com/zhzheng92/AG2PI_GWAS_workshop_June2021/blob/main/GWAS_models.jpg">
</p>
 

To get ready for the tutorials, please download the following software/R packages to your local machine

1. [R](https://www.r-project.org/) and [RStudio](https://www.rstudio.com/products/rstudio/download/) . CAUTION !! **please use R 4.1.3** not R 4.2.xx !!
2. R packages: [tidyverse](https://www.tidyverse.org/packages/), [GAPIT3](https://zzlab.net/GAPIT/), [qqman](https://cran.r-project.org/web/packages/qqman/index.html), [lme4](https://cran.r-project.org/web/packages/lme4/), [lmerTest](https://cran.r-project.org/web/packages/lmerTest/index.html)

## The example scripts for running GWAS with GAPIT using different models can be found in this directory.
The genotypes and phenotypes needed for GWAS, and additonal principal component (PC) and kinship matrices are provided in the ../dataxx/ directories.

You may download the repository as a zip file to your own machine and appropriate folder: Use **CODE / Download ZIP**. After extraction, all elements will be in place.  

Alternatively, you may download the data files, download or copy the scripts to your own machine and appropriate folder, and change the directory as needed to run the analysis.  
