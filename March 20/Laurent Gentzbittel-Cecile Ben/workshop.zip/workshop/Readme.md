## Please download the zip
 and unzip in your prefered folder.
 
***Happy GWAS !!***
