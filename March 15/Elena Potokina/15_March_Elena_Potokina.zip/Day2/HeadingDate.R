######### QTL mapping by the simplest way #############################################################

## The objective of this example is to create a short and simple script to explain how to find   
## a molecular marker linked to the variation of a phenotypic trait 
## For each of 25 molecular markers the population was divided into two classes according the allele (a/b), 
## inherited from the parents and heading date variance was compared for both classes via one-way ANOVA test

######### PREPARATION OF THE WORKING INTERFACE IN R ###########################################
### I. Set working directory  ####
#On RStudio: tab 'Session'-> Set Working Directory -> Choose Directory.
#Choose the directory containing the datafile and the associated R script.

### II. Possibly, installation of new R packages needed for the analysis on RStudio:
#Click on the 'Packages' tab in the bottom-right window of R Studio interface->'Install Packages'
#Comment #1: R package installation requires a connection to internet
#Comment #2: Once packages have been installed, no need to re-install them again when you close-open again RStudio.

### III. Initialization of the working space
# To erase all graphs
graphics.off()
# To erase objects from the working space - Clean up of the memory
rm(list = ls())

## The packages (libraries) below should be installed

library(Hmisc)      ## for describe()
library(openxlsx)   ## to import Excel files
####################################
# Import of data
####################################

## before loading data, open the excel file. Inspect organisation. Understand what are the factors, what are the variables.

## import from Excel to R 
Heading <- read.xlsx("HD.xlsx", sheet = 1, startRow = 1, colNames = TRUE)

# The data
Heading

# Structure of dataset -- important, to check if data import is OK
str(Heading)  # here we see the structure of input dataset   

# A quick description of all columns of the dataset
describe(Heading)

attach(Heading)

ana1 <- aov(HeadingDate ~ ASE1A)  
summary(ana1)
boxplot(HeadingDate ~ ASE1A)

ana2 <- aov(HeadingDate ~ ABG058)  
summary(ana2)
boxplot(HeadingDate ~ ABG058)

ana3 <- aov(HeadingDate ~ MWG878)  
summary(ana3)
boxplot(HeadingDate ~ MWG878)

ana4 <- aov(HeadingDate ~ RbcS)  
summary(ana4)
boxplot(HeadingDate ~ RbcS)

ana5 <- aov(HeadingDate ~ BCD351F)  
summary(ana5)
boxplot(HeadingDate ~ BCD351F)

ana6 <- aov(HeadingDate ~ ABC156A)  
summary(ana6)
boxplot(HeadingDate ~ ABC156A)

ana7 <- aov(HeadingDate ~ MWG858)  
summary(ana7)
boxplot(HeadingDate ~ MWG858)

ana8 <- aov(HeadingDate ~ ABG358)  
summary(ana8)
boxplot(HeadingDate ~ ABG358)

ana9 <- aov(HeadingDate ~ ABG459)  
summary(ana9)
boxplot(HeadingDate ~ ABG459)
      
ana10 <- aov(HeadingDate ~ Pox)  
summary(ana10)
boxplot(HeadingDate ~ Pox)

ana11 <- aov(HeadingDate ~ Adh8)  
summary(ana11)
boxplot(HeadingDate ~ Adh8)

ana12 <- aov(HeadingDate ~ MWG557)  
summary(ana12)
boxplot(HeadingDate ~ MWG557)

ana13 <- aov(HeadingDate ~ ABG316C)  
summary(ana13)
boxplot(HeadingDate ~ ABG316C)

ana14 <- aov(HeadingDate ~ ABC167B)  
summary(ana14)
boxplot(HeadingDate ~ ABC167B)

ana15 <- aov(HeadingDate ~ bBE54D)  
summary(ana15)
boxplot(HeadingDate ~ bBE54D)

ana16 <- aov(HeadingDate ~ CDO588)  
summary(ana16)
boxplot(HeadingDate ~ CDO588)

ana17 <- aov(HeadingDate ~ MWG503)  
summary(ana17)
boxplot(HeadingDate ~ MWG503)

ana18 <- aov(HeadingDate ~ Crg3A)  
summary(ana18)
boxplot(HeadingDate ~ Crg3A)

ana19 <- aov(HeadingDate ~ ABC252)  
summary(ana19)
boxplot(HeadingDate ~ ABC252)

ana20 <- aov(HeadingDate ~ ABC157)  
summary(ana20)
boxplot(HeadingDate ~ ABC157)

ana21 <- aov(HeadingDate ~ ABG316E)  
summary(ana21)
boxplot(HeadingDate ~ ABG316E)

ana22 <- aov(HeadingDate ~ ABC153)  
summary(ana22)
boxplot(HeadingDate ~ ABC153)

ana23 <- aov(HeadingDate ~ Pcr1)  
summary(ana23)
boxplot(HeadingDate ~ Pcr1)

ana24 <- aov(HeadingDate ~ cMWG720)  
summary(ana24)
boxplot(HeadingDate ~ cMWG720)

ana25 <- aov(HeadingDate ~ bBE54C)  
summary(ana25)
boxplot(HeadingDate ~ bBE54C)




